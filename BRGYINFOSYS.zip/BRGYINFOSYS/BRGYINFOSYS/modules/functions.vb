﻿Module functions
    Public Sub ClearAll(ByVal group As Object, ByVal what As String)

        Select Case what
            Case "Usertype"
                For Each ctrl As Control In group.Controls
                    If ctrl.GetType Is GetType(TextBox) Then
                        ctrl.Text = Nothing
                    End If
                Next
            Case "household"
                For Each ctrl As Control In group.Controls
                    If ctrl.GetType Is GetType(TextBox) Then
                        ctrl.Text = Nothing
                    End If
                Next



        End Select
    End Sub


    Public Sub fillcombo(ByVal combo As Object, ByVal member As String, ByVal idparam As String)
        Dim publictable As New DataTable
        Try
            da.SelectCommand = cmd
            da.Fill(publictable)
            With combo
                .DataSource = publictable
                .displaymember = member
                .valuemember = idparam
            End With

            da.Dispose()

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information)
        End Try
    End Sub
    Public Function NumRows() As Integer
        Try
            con.Open()
            dReader = cmd.ExecuteReader()
            Do While dReader.Read = True

                Return dReader(0)
            Loop

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            con.Close()

        End Try
    End Function
    Public Sub Visible_Button(ByVal result As Boolean)

        If result = True Then
            With Main
                If usertype = "ADMINISTRATOR" Then

                    .tlsofficials.Enabled = True
                    .tlshousehold.Enabled = True
                    .tlsbrgycl.Enabled = True
                    .tlsPurok.Enabled = True

                ElseIf usertype = "SECRETARY" Then
                    .tlsofficials.Enabled = True
                    .tlshousehold.Enabled = True
                    .tlsbrgycl.Enabled = True
                    .tlsPurok.Enabled = True
                End If


            End With
        Else
            With Main
                .tlsofficials.Enabled = False
                .tlshousehold.Enabled = False
                .tlsbrgycl.Enabled = False
                .tlsPurok.Enabled = False

            End With
        End If
    End Sub
End Module
