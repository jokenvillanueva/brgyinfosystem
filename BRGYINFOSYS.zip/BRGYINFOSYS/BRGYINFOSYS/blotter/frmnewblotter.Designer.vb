﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmnewblotter
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.StatLbltime = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.btnsave = New System.Windows.Forms.Button
        Me.lblresid = New System.Windows.Forms.Label
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Lblsupliertitle = New System.Windows.Forms.Label
        Me.txtencoder = New System.Windows.Forms.TextBox
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.brgycaptain = New System.Windows.Forms.Label
        Me.dtdate = New System.Windows.Forms.DateTimePicker
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.TXTADDRESS = New System.Windows.Forms.TextBox
        Me.btnsearch = New System.Windows.Forms.Button
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtlname = New System.Windows.Forms.TextBox
        Me.txtdetails = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Panel2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'StatLbltime
        '
        Me.StatLbltime.AutoSize = True
        Me.StatLbltime.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatLbltime.Location = New System.Drawing.Point(339, 16)
        Me.StatLbltime.Name = "StatLbltime"
        Me.StatLbltime.Size = New System.Drawing.Size(49, 16)
        Me.StatLbltime.TabIndex = 81
        Me.StatLbltime.Text = "Label2"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(245, 16)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(97, 16)
        Me.Label4.TabIndex = 79
        Me.Label4.Text = "Time of Filling :"
        '
        'btnsave
        '
        Me.btnsave.Location = New System.Drawing.Point(120, 337)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(159, 39)
        Me.btnsave.TabIndex = 46
        Me.btnsave.Text = "Save"
        Me.btnsave.UseVisualStyleBackColor = True
        '
        'lblresid
        '
        Me.lblresid.AutoSize = True
        Me.lblresid.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblresid.Location = New System.Drawing.Point(6, 16)
        Me.lblresid.Name = "lblresid"
        Me.lblresid.Size = New System.Drawing.Size(69, 16)
        Me.lblresid.TabIndex = 77
        Me.lblresid.Text = "Fullname :"
        Me.lblresid.Visible = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.Highlight
        Me.Panel2.Controls.Add(Me.Lblsupliertitle)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(454, 60)
        Me.Panel2.TabIndex = 45
        '
        'Lblsupliertitle
        '
        Me.Lblsupliertitle.AutoSize = True
        Me.Lblsupliertitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblsupliertitle.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Lblsupliertitle.Location = New System.Drawing.Point(17, 20)
        Me.Lblsupliertitle.Name = "Lblsupliertitle"
        Me.Lblsupliertitle.Size = New System.Drawing.Size(133, 25)
        Me.Lblsupliertitle.TabIndex = 0
        Me.Lblsupliertitle.Text = "New Blotter" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'txtencoder
        '
        Me.txtencoder.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtencoder.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtencoder.BackColor = System.Drawing.SystemColors.HighlightText
        Me.txtencoder.Enabled = False
        Me.txtencoder.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtencoder.Location = New System.Drawing.Point(109, 221)
        Me.txtencoder.Name = "txtencoder"
        Me.txtencoder.Size = New System.Drawing.Size(196, 22)
        Me.txtencoder.TabIndex = 60
        '
        'Timer1
        '
        '
        'brgycaptain
        '
        Me.brgycaptain.AutoSize = True
        Me.brgycaptain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.brgycaptain.Location = New System.Drawing.Point(30, 227)
        Me.brgycaptain.Name = "brgycaptain"
        Me.brgycaptain.Size = New System.Drawing.Size(65, 16)
        Me.brgycaptain.TabIndex = 59
        Me.brgycaptain.Text = "Encoder :"
        '
        'dtdate
        '
        Me.dtdate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtdate.Location = New System.Drawing.Point(109, 121)
        Me.dtdate.Name = "dtdate"
        Me.dtdate.Size = New System.Drawing.Size(197, 20)
        Me.dtdate.TabIndex = 61
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.TXTADDRESS)
        Me.GroupBox1.Controls.Add(Me.btnsearch)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.txtlname)
        Me.GroupBox1.Controls.Add(Me.StatLbltime)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.lblresid)
        Me.GroupBox1.Controls.Add(Me.txtencoder)
        Me.GroupBox1.Controls.Add(Me.brgycaptain)
        Me.GroupBox1.Controls.Add(Me.dtdate)
        Me.GroupBox1.Controls.Add(Me.txtdetails)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Location = New System.Drawing.Point(11, 59)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(424, 272)
        Me.GroupBox1.TabIndex = 44
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Details"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(37, 99)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(65, 16)
        Me.Label10.TabIndex = 86
        Me.Label10.Text = "Address ;"
        '
        'TXTADDRESS
        '
        Me.TXTADDRESS.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TXTADDRESS.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TXTADDRESS.BackColor = System.Drawing.SystemColors.HighlightText
        Me.TXTADDRESS.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXTADDRESS.Location = New System.Drawing.Point(109, 93)
        Me.TXTADDRESS.Name = "TXTADDRESS"
        Me.TXTADDRESS.Size = New System.Drawing.Size(304, 22)
        Me.TXTADDRESS.TabIndex = 85
        '
        'btnsearch
        '
        Me.btnsearch.Location = New System.Drawing.Point(312, 61)
        Me.btnsearch.Name = "btnsearch"
        Me.btnsearch.Size = New System.Drawing.Size(52, 23)
        Me.btnsearch.TabIndex = 83
        Me.btnsearch.Text = "Search"
        Me.btnsearch.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(34, 67)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(69, 16)
        Me.Label2.TabIndex = 84
        Me.Label2.Text = "Fullname :"
        '
        'txtlname
        '
        Me.txtlname.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtlname.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtlname.BackColor = System.Drawing.SystemColors.HighlightText
        Me.txtlname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtlname.Location = New System.Drawing.Point(109, 61)
        Me.txtlname.Name = "txtlname"
        Me.txtlname.Size = New System.Drawing.Size(197, 22)
        Me.txtlname.TabIndex = 82
        '
        'txtdetails
        '
        Me.txtdetails.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtdetails.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtdetails.BackColor = System.Drawing.SystemColors.HighlightText
        Me.txtdetails.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdetails.Location = New System.Drawing.Point(109, 147)
        Me.txtdetails.Multiline = True
        Me.txtdetails.Name = "txtdetails"
        Me.txtdetails.Size = New System.Drawing.Size(304, 68)
        Me.txtdetails.TabIndex = 64
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(47, 153)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(56, 16)
        Me.Label7.TabIndex = 65
        Me.Label7.Text = "Details :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(10, 125)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(95, 16)
        Me.Label6.TabIndex = 63
        Me.Label6.Text = "Date of Filling :"
        '
        'frmnewblotter
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(454, 381)
        Me.Controls.Add(Me.btnsave)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "frmnewblotter"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents StatLbltime As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btnsave As System.Windows.Forms.Button
    Friend WithEvents lblresid As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Lblsupliertitle As System.Windows.Forms.Label
    Friend WithEvents txtencoder As System.Windows.Forms.TextBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents brgycaptain As System.Windows.Forms.Label
    Friend WithEvents dtdate As System.Windows.Forms.DateTimePicker
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtdetails As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents btnsearch As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtlname As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TXTADDRESS As System.Windows.Forms.TextBox
End Class
