﻿Module blottercontroller
    Public Function SaveBlotter(ByVal saving As String, ByVal sqlstring As String) As Boolean

        Try

            If saving = "SaveOnly" Then
                sql = sqlstring
            ElseIf saving = "UpdateOnly" Then
                sql = sqlstring

            End If
            con.Open()
            cmd.Connection = con
            cmd.CommandText = sql
            With frmnewblotter
                If saving = "SaveOnly" Then
                    cmd.Parameters.AddWithValue("@RESID", .Text)
                    cmd.Parameters.AddWithValue("@FULLNAME", .txtlname.Text)
                    cmd.Parameters.AddWithValue("@ADDRESS", .TXTADDRESS.Text)
                    cmd.Parameters.AddWithValue("@DATEBLOTTER", Format(.dtdate.Value, "yyyy-MM-dd"))
                    cmd.Parameters.AddWithValue("@TIMEBLOTTER", .StatLbltime.Text)
                    cmd.Parameters.AddWithValue("@DETAILS", .txtdetails.Text)
                    cmd.Parameters.AddWithValue("@ENCODER", .txtencoder.Text)


                ElseIf saving = "UpdateOnly" Then

                    cmd.Parameters.AddWithValue("@RESID", .lblresid.Text)
                    cmd.Parameters.AddWithValue("@FULLNAME", .txtlname.Text)
                    cmd.Parameters.AddWithValue("@ADDRESS", .TXTADDRESS.Text)
                    cmd.Parameters.AddWithValue("@DATEBLOTTER", Format(.dtdate.Value, "yyyy-MM-dd"))
                    cmd.Parameters.AddWithValue("@DETAILS", .txtdetails.Text)
                    cmd.Parameters.AddWithValue("@RECNO", .Text)

                End If

            End With
            result = cmd.ExecuteNonQuery
            If result > 0 Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            cmd.Parameters.Clear()
            cmd.Dispose()
            con.Close()

        End Try
    End Function

    Public Sub LoadBlotter(ByVal obj As Object, ByVal param As String)
        Try
            con.Open()
            dReader = cmd.ExecuteReader()
            '  obj.Rows.Clear()
            Select Case param
                Case "Blotter"
                    obj.Rows.Clear()
                    Do While dReader.Read = True
                        obj.Rows.Add(dReader(0), dReader(1), dReader(2), dReader(3), dReader(4), dReader(5), dReader(6), dReader(7))

                    Loop
            End Select
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            da.Dispose()
            con.Close()
        End Try
    End Sub



    Public Sub loadsingleBlotter(ByVal param As String)
        Try
            con.Open()
            dReader = cmd.ExecuteReader()
            '  obj.Rows.Clear()
            Select Case param
                Case "blotter"
                    Do While dReader.Read = True
                        With frmnewblotter
                            '`RECNO`, `RESID`, `FULLNAME`, `ADDRESS`, `DATEBLOTTER`, `TIMEBLOTTER`, `DETAILS`,ENCODER
                            .Text = dReader("RECNO")
                            .lblresid.Text = dReader("RESID")
                            .txtlname.Text = dReader("FULLNAME")
                            .TXTADDRESS.Text = dReader("ADDRESS")
                            .dtdate.Value = Format(dReader("DATEBLOTTER"), "yyyy-MM-dd")
                            .StatLbltime.Text = dReader("timefile")
                            .txtdetails.Text = dReader("DETAILS")
                            .txtencoder.Text = dReader("ENCODER")


                        End With

                    Loop
            End Select
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            da.Dispose()
            con.Close()
        End Try
    End Sub
End Module
