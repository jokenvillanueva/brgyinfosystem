﻿Public Class frmnewblotter

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        CLEARANCE = "BLOTTER"
        frmhousehold.Show()
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        If btnsave.Text = "Save" Then
            sql = "INSERT INTO `tblblotter` ( `RESID`, `FULLNAME`, `ADDRESS`, `DATEBLOTTER`, `TIMEBLOTTER`, `DETAILS`, `ENCODER`) " & _
            " VALUES ( @RESID, @FULLNAME, @ADDRESS, @DATEBLOTTER, @TIMEBLOTTER, @DETAILS, @ENCODER);"


            issucess = SaveBlotter("SaveOnly", sql)

            If issucess = True Then
                MsgBox("New Blotter has been added!")
            Else
                MsgBox("No Blotter has been added!")
            End If

            jokenfindthis("SELECT * FROM `tblblotter`")
            LoadBlotter(frmblotter.DataGridView1, "Blotter")
            Me.Close()
        Else
            sql = "UPDATE `tblblotter` SET `RESID` =@RESID, `FULLNAME` = @FULLNAME, `ADDRESS` = @ADDRESS, `DATEBLOTTER` = @DATEBLOTTER, " & _
            " `DETAILS` = @DETAILS WHERE `tblblotter`.`RECNO` = @RECNO;"

            issucess = SaveBlotter("UpdateOnly", sql)

            If issucess = True Then
                MsgBox("Blotter has been updated!")
            Else
                MsgBox("No Blotter has been updated!")
            End If

            jokenfindthis("SELECT * FROM `tblblotter`")
            LoadBlotter(frmblotter.DataGridView1, "Blotter")
            Me.Close()
        End If
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        StatLbltime.Text = Date.Now.ToString("H:mm:ss")
    End Sub
End Class