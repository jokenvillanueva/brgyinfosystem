﻿Public Class frmblotter

    Private Sub frmblotter_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        jokenfindthis("SELECT `RECNO`, `RESID`, `FULLNAME`, `ADDRESS`, `DATEBLOTTER`, `TIMEBLOTTER`, `DETAILS`,ENCODER FROM `tblblotter`")
        LoadBlotter(DataGridView1, "Blotter")
    End Sub

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        frmnewblotter.Timer1.Start()
        frmnewblotter.Show()


    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        With frmnewblotter
            GLOBALid = DataGridView1.CurrentRow.Cells(0).Value

            jokenfindthis("SELECT `RECNO`, `RESID`, `FULLNAME`, `ADDRESS`, `DATEBLOTTER`, TIME_FORMAT(`TIMEBLOTTER`,  '%H:%i:%s' ) as timefile, `DETAILS`,ENCODER FROM `tblblotter` WHERE RECNO=" & GLOBALid & "")
            loadsingleBlotter("blotter")



            .Lblsupliertitle.Text = "Edit Blotter"
            .btnsave.Text = "Update"
            .btnsearch.Enabled = False

            .Show()

        End With
    End Sub
End Class