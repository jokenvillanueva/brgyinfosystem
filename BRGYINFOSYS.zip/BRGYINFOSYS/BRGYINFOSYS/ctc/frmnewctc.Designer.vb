﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmnewctc
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Lblsupliertitle = New System.Windows.Forms.Label
        Me.btnsave = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.TXTPLACEISSUE = New System.Windows.Forms.TextBox
        Me.brgycaptain = New System.Windows.Forms.Label
        Me.TXTYEAR = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.TXTDATEGIVEN = New System.Windows.Forms.DateTimePicker
        Me.TXTCIVIL = New System.Windows.Forms.TextBox
        Me.TXTGENDER = New System.Windows.Forms.TextBox
        Me.btnsearch = New System.Windows.Forms.Button
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.TXTADDRESS = New System.Windows.Forms.TextBox
        Me.txtlname = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtpob = New System.Windows.Forms.TextBox
        Me.DTPpick = New System.Windows.Forms.DateTimePicker
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtctcno = New System.Windows.Forms.TextBox
        Me.lblresid = New System.Windows.Forms.Label
        Me.Panel2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.Highlight
        Me.Panel2.Controls.Add(Me.Lblsupliertitle)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(490, 60)
        Me.Panel2.TabIndex = 42
        '
        'Lblsupliertitle
        '
        Me.Lblsupliertitle.AutoSize = True
        Me.Lblsupliertitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblsupliertitle.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Lblsupliertitle.Location = New System.Drawing.Point(17, 20)
        Me.Lblsupliertitle.Name = "Lblsupliertitle"
        Me.Lblsupliertitle.Size = New System.Drawing.Size(340, 25)
        Me.Lblsupliertitle.TabIndex = 0
        Me.Lblsupliertitle.Text = "New Community Tax Clearance"
        '
        'btnsave
        '
        Me.btnsave.Location = New System.Drawing.Point(138, 415)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(159, 39)
        Me.btnsave.TabIndex = 43
        Me.btnsave.Text = "Save"
        Me.btnsave.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lblresid)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txtctcno)
        Me.GroupBox1.Controls.Add(Me.DTPpick)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.txtpob)
        Me.GroupBox1.Controls.Add(Me.TXTPLACEISSUE)
        Me.GroupBox1.Controls.Add(Me.brgycaptain)
        Me.GroupBox1.Controls.Add(Me.TXTYEAR)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.TXTDATEGIVEN)
        Me.GroupBox1.Controls.Add(Me.TXTCIVIL)
        Me.GroupBox1.Controls.Add(Me.TXTGENDER)
        Me.GroupBox1.Controls.Add(Me.btnsearch)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.TXTADDRESS)
        Me.GroupBox1.Controls.Add(Me.txtlname)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 66)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(462, 343)
        Me.GroupBox1.TabIndex = 44
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Details"
        '
        'TXTPLACEISSUE
        '
        Me.TXTPLACEISSUE.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TXTPLACEISSUE.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TXTPLACEISSUE.BackColor = System.Drawing.SystemColors.HighlightText
        Me.TXTPLACEISSUE.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXTPLACEISSUE.Location = New System.Drawing.Point(127, 46)
        Me.TXTPLACEISSUE.Name = "TXTPLACEISSUE"
        Me.TXTPLACEISSUE.Size = New System.Drawing.Size(197, 22)
        Me.TXTPLACEISSUE.TabIndex = 60
        '
        'brgycaptain
        '
        Me.brgycaptain.AutoSize = True
        Me.brgycaptain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.brgycaptain.Location = New System.Drawing.Point(22, 52)
        Me.brgycaptain.Name = "brgycaptain"
        Me.brgycaptain.Size = New System.Drawing.Size(98, 16)
        Me.brgycaptain.TabIndex = 59
        Me.brgycaptain.Text = "Place of Issue :"
        '
        'TXTYEAR
        '
        Me.TXTYEAR.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TXTYEAR.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TXTYEAR.BackColor = System.Drawing.SystemColors.HighlightText
        Me.TXTYEAR.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXTYEAR.Location = New System.Drawing.Point(127, 19)
        Me.TXTYEAR.Name = "TXTYEAR"
        Me.TXTYEAR.Size = New System.Drawing.Size(197, 22)
        Me.TXTYEAR.TabIndex = 58
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(77, 25)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(43, 16)
        Me.Label4.TabIndex = 57
        Me.Label4.Text = "Year :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(35, 78)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(86, 16)
        Me.Label3.TabIndex = 56
        Me.Label3.Text = "Date Issued :"
        '
        'TXTDATEGIVEN
        '
        Me.TXTDATEGIVEN.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.TXTDATEGIVEN.Location = New System.Drawing.Point(127, 74)
        Me.TXTDATEGIVEN.Name = "TXTDATEGIVEN"
        Me.TXTDATEGIVEN.Size = New System.Drawing.Size(197, 20)
        Me.TXTDATEGIVEN.TabIndex = 55
        '
        'TXTCIVIL
        '
        Me.TXTCIVIL.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TXTCIVIL.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TXTCIVIL.BackColor = System.Drawing.SystemColors.HighlightText
        Me.TXTCIVIL.Enabled = False
        Me.TXTCIVIL.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXTCIVIL.Location = New System.Drawing.Point(126, 220)
        Me.TXTCIVIL.Name = "TXTCIVIL"
        Me.TXTCIVIL.Size = New System.Drawing.Size(197, 22)
        Me.TXTCIVIL.TabIndex = 51
        '
        'TXTGENDER
        '
        Me.TXTGENDER.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TXTGENDER.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TXTGENDER.BackColor = System.Drawing.SystemColors.HighlightText
        Me.TXTGENDER.Enabled = False
        Me.TXTGENDER.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXTGENDER.Location = New System.Drawing.Point(126, 189)
        Me.TXTGENDER.Name = "TXTGENDER"
        Me.TXTGENDER.Size = New System.Drawing.Size(197, 22)
        Me.TXTGENDER.TabIndex = 48
        '
        'btnsearch
        '
        Me.btnsearch.Location = New System.Drawing.Point(329, 158)
        Me.btnsearch.Name = "btnsearch"
        Me.btnsearch.Size = New System.Drawing.Size(52, 23)
        Me.btnsearch.TabIndex = 1
        Me.btnsearch.Text = "Search"
        Me.btnsearch.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(51, 165)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(69, 16)
        Me.Label15.TabIndex = 28
        Me.Label15.Text = "Fullname :"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(41, 223)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(79, 16)
        Me.Label12.TabIndex = 23
        Me.Label12.Text = "Civil Status :"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(61, 195)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(59, 16)
        Me.Label11.TabIndex = 21
        Me.Label11.Text = "Gender :"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(54, 254)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(65, 16)
        Me.Label10.TabIndex = 19
        Me.Label10.Text = "Address ;"
        '
        'TXTADDRESS
        '
        Me.TXTADDRESS.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TXTADDRESS.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TXTADDRESS.BackColor = System.Drawing.SystemColors.HighlightText
        Me.TXTADDRESS.Enabled = False
        Me.TXTADDRESS.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXTADDRESS.Location = New System.Drawing.Point(126, 248)
        Me.TXTADDRESS.Name = "TXTADDRESS"
        Me.TXTADDRESS.Size = New System.Drawing.Size(318, 22)
        Me.TXTADDRESS.TabIndex = 18
        '
        'txtlname
        '
        Me.txtlname.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtlname.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtlname.BackColor = System.Drawing.SystemColors.HighlightText
        Me.txtlname.Enabled = False
        Me.txtlname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtlname.Location = New System.Drawing.Point(126, 159)
        Me.txtlname.Name = "txtlname"
        Me.txtlname.Size = New System.Drawing.Size(197, 22)
        Me.txtlname.TabIndex = 1
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(32, 280)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(92, 16)
        Me.Label5.TabIndex = 62
        Me.Label5.Text = "Place of Birth :"
        '
        'txtpob
        '
        Me.txtpob.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtpob.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtpob.BackColor = System.Drawing.SystemColors.HighlightText
        Me.txtpob.Enabled = False
        Me.txtpob.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpob.Location = New System.Drawing.Point(126, 276)
        Me.txtpob.Name = "txtpob"
        Me.txtpob.Size = New System.Drawing.Size(196, 22)
        Me.txtpob.TabIndex = 61
        '
        'DTPpick
        '
        Me.DTPpick.Enabled = False
        Me.DTPpick.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DTPpick.Location = New System.Drawing.Point(126, 304)
        Me.DTPpick.MaxDate = New Date(2200, 12, 31, 0, 0, 0, 0)
        Me.DTPpick.MinDate = New Date(1900, 1, 1, 0, 0, 0, 0)
        Me.DTPpick.Name = "DTPpick"
        Me.DTPpick.Size = New System.Drawing.Size(196, 20)
        Me.DTPpick.TabIndex = 64
        Me.DTPpick.Value = New Date(2000, 1, 25, 0, 0, 0, 0)
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(40, 307)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(86, 16)
        Me.Label9.TabIndex = 63
        Me.Label9.Text = "Date of Birth :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(51, 106)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 16)
        Me.Label1.TabIndex = 66
        Me.Label1.Text = "CTC No.  :"
        '
        'txtctcno
        '
        Me.txtctcno.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtctcno.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtctcno.BackColor = System.Drawing.SystemColors.HighlightText
        Me.txtctcno.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtctcno.Location = New System.Drawing.Point(127, 100)
        Me.txtctcno.Name = "txtctcno"
        Me.txtctcno.Size = New System.Drawing.Size(196, 22)
        Me.txtctcno.TabIndex = 65
        '
        'lblresid
        '
        Me.lblresid.AutoSize = True
        Me.lblresid.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblresid.Location = New System.Drawing.Point(345, 16)
        Me.lblresid.Name = "lblresid"
        Me.lblresid.Size = New System.Drawing.Size(69, 16)
        Me.lblresid.TabIndex = 78
        Me.lblresid.Text = "Fullname :"
        Me.lblresid.Visible = False
        '
        'frmnewctc
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(490, 487)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.btnsave)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "frmnewctc"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Lblsupliertitle As System.Windows.Forms.Label
    Friend WithEvents btnsave As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TXTPLACEISSUE As System.Windows.Forms.TextBox
    Friend WithEvents brgycaptain As System.Windows.Forms.Label
    Friend WithEvents TXTYEAR As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TXTDATEGIVEN As System.Windows.Forms.DateTimePicker
    Friend WithEvents TXTCIVIL As System.Windows.Forms.TextBox
    Friend WithEvents TXTGENDER As System.Windows.Forms.TextBox
    Friend WithEvents btnsearch As System.Windows.Forms.Button
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TXTADDRESS As System.Windows.Forms.TextBox
    Friend WithEvents txtlname As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtpob As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtctcno As System.Windows.Forms.TextBox
    Friend WithEvents DTPpick As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents lblresid As System.Windows.Forms.Label
End Class
