﻿Module ctcController
    Public Function SaveCTC(ByVal saving As String, ByVal sqlstring As String) As Boolean

        Try


            If saving = "SaveOnly" Then
                sql = sqlstring
            ElseIf saving = "UpdateOnly" Then
                sql = sqlstring

            End If
            con.Open()
            cmd.Connection = con
            cmd.CommandText = sql
            With frmnewctc
                If saving = "SaveOnly" Then
                    'INSERT INTO `tblctc` (`CtcYear`, `PlaceIssue`, `DateIssued`, `Fullname`, `CTCNo`, `RESID`) " & _
                    '  " VALUES (@CtcYear, @PlaceIssue, @DateIssued, @Fullname, @CTCNo, @RESID);"

                    cmd.Parameters.AddWithValue("@CtcYear", .TXTYEAR.Text)
                    cmd.Parameters.AddWithValue("@PlaceIssue", .TXTPLACEISSUE.Text)
                    cmd.Parameters.AddWithValue("@DateIssued", Format(.TXTDATEGIVEN.Value, "yyyy-MM-dd"))
                    cmd.Parameters.AddWithValue("@FULLNAME", .txtlname.Text)
                    cmd.Parameters.AddWithValue("@CTCNo", .txtctcno.Text)
                    cmd.Parameters.AddWithValue("@RESID", Val(.lblresid.Text))


                ElseIf saving = "UpdateOnly" Then
                    cmd.Parameters.AddWithValue("@CtcYear", .TXTYEAR.Text)
                    cmd.Parameters.AddWithValue("@PlaceIssue", .TXTPLACEISSUE.Text)
                    cmd.Parameters.AddWithValue("@DateIssued", Format(.TXTDATEGIVEN.Value, "yyyy-MM-dd"))
                    cmd.Parameters.AddWithValue("@FULLNAME", .txtlname.Text)
                    cmd.Parameters.AddWithValue("@CTCNo", .txtctcno.Text)
                    cmd.Parameters.AddWithValue("@RESID", Val(.lblresid.Text))
                    cmd.Parameters.AddWithValue("@ID", Val(.Text))

                End If

            End With
            result = cmd.ExecuteNonQuery
            If result > 0 Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            cmd.Parameters.Clear()
            cmd.Dispose()
            con.Close()

        End Try
    End Function

    Public Sub LoadCTC(ByVal obj As Object, ByVal param As String)
        Try
            con.Open()
            dReader = cmd.ExecuteReader()
            '  obj.Rows.Clear()
            Select Case param
                Case "CTC"
                    obj.Rows.Clear()
                    Do While dReader.Read = True

                        obj.Rows.Add(dReader(0), dReader(1), dReader(2), dReader(3), dReader(4), dReader(5), dReader(6), dReader(7), dReader(8), dReader(9), dReader(10), dReader(11))

                    Loop
            End Select
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            da.Dispose()
            con.Close()
        End Try
    End Sub

    Public Sub loadsinglectc(ByVal param As String)
        Try
            con.Open()
            dReader = cmd.ExecuteReader()
            '  obj.Rows.Clear()
            Select Case param
                Case "CTC"
                    Do While dReader.Read = True
                        With frmnewctc
                            '`ID`, `CtcYear`, `PlaceIssue`, `DateIssued`, `Fullname`, `CTCNo`, `RESID`
                            .Text = dReader("ID")
                            .lblresid.Text = dReader("RESID")
                            .TXTYEAR.Text = dReader("CtcYear")
                            .TXTPLACEISSUE.Text = dReader("PlaceIssue")
                            .TXTDATEGIVEN.Text = dReader("DateIssued")
                            .txtctcno.Text = dReader("CTCNo")
                            .txtlname.Text = dReader("FULLNAME")

                        End With
                    Loop

            End Select
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            da.Dispose()
            con.Close()
        End Try
    End Sub
End Module
