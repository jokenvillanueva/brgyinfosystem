﻿Public Class frmnewctc

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        CLEARANCE = "CTC"
        frmhousehold.Show()
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        If btnsave.Text = "Save" Then
            sql = "INSERT INTO `tblctc` (`CtcYear`, `PlaceIssue`, `DateIssued`, `Fullname`, `CTCNo`, `RESID`) " & _
            " VALUES (@CtcYear, @PlaceIssue, @DateIssued, @Fullname, @CTCNo, @RESID);"

            issucess = SaveCTC("SaveOnly", sql)

            If issucess = True Then
                MsgBox("New Communitiy Tax Clearance has been added!")
            Else
                MsgBox("No Communitiy Tax Clearance has been added!")
            End If

            jokenfindthis("SELECT `ID`,RESID,`Fullname`, `CtcYear`, `PlaceIssue`, `DateIssued`,  `CTCNo`, " & _
                          " `SEX`,`CIVIL`,CONCAT(`NO`,`STREET`,`PRK`,'Barangay Uno, Katipunan, Zamboanga del Norte')AS ADDRESS, `POB`,`DOB` FROM `tblctc` c, tblresidence r WHERE c.`RESID` = r.RESIDENCEID")
            LoadCTC(frmctc.DataGridView1, "CTC")
            Me.Close()
        Else
            sql = "UPDATE `tblctc` SET `CtcYear` = @CtcYear, `PlaceIssue` = @PlaceIssue, `DateIssued` = @DateIssued, `Fullname` = @Fullname, `CTCNo` = @CTCNo, `RESID` = @RESID WHERE `tblctc`.`ID` = @ID;"

            issucess = SaveCTC("UpdateOnly", sql)

            If issucess = True Then
                MsgBox("Communitiy Tax Clearance has been updated!")
            Else
                MsgBox("Communitiy Tax Clearance has been updated!")
            End If

            jokenfindthis("SELECT `ID`,RESID,`Fullname`, `CtcYear`, `PlaceIssue`, `DateIssued`,  `CTCNo`, `SEX`,`CIVIL`,CONCAT(`NO`,`STREET`,`PRK`,'Barangay Uno, Katipunan, Zamboanga del Norte')AS ADDRESS, `POB`,`DOB` FROM `tblctc` c, tblresidence r WHERE c.`RESID` = r.RESIDENCEID")
            LoadCTC(frmctc.DataGridView1, "CTC")
            Me.Close()

        End If
    End Sub
End Class