﻿Public Class frmctc

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        frmnewctc.Show()
    End Sub

    Private Sub frmctc_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        jokenfindthis("SELECT `ID`,RESID,`Fullname`, `CtcYear`, `PlaceIssue`, `DateIssued`,  `CTCNo`, `SEX`, " & _
                      " `CIVIL`,CONCAT(`NO`,`STREET`,`PRK`,'Barangay Uno, Katipunan, Zamboanga del Norte')AS ADDRESS, " & _
                      " `POB`,`DOB` FROM `tblctc` c, tblresidence r WHERE c.`RESID` = r.RESIDENCEID")
        LoadCTC(DataGridView1, "CTC")

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        With frmnewctc
            GLOBALid = DataGridView1.CurrentRow.Cells(0).Value

            jokenfindthis("SELECT * FROM `tblctc` where ID=" & GLOBALid & "")
            loadsinglectc("CTC")
            CLEARANCE = "CTC"
            jokenfindthis("SELECT * FROM `tblresidence` where RESIDENCEID=" & DataGridView1.CurrentRow.Cells(1).Value & "")
            loadsingleHousehold("household")



            .Lblsupliertitle.Text = "Edit Community Tax Clearance"
            .btnsave.Text = "Update"
            .btnsearch.Enabled = False

            .Show()

        End With
    End Sub

    Private Sub txtsearch_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtsearch.TextChanged
        jokenfindthis("SELECT `ID`,RESID,`Fullname`, `CtcYear`, `PlaceIssue`, `DateIssued`,  `CTCNo`, `SEX`, " & _
                    " `CIVIL`,CONCAT(`NO`,`STREET`,`PRK`,'Barangay Uno, Katipunan, Zamboanga del Norte')AS ADDRESS, " & _
                    " `POB`,`DOB` FROM `tblctc` c, tblresidence r WHERE c.`RESID` = r.RESIDENCEID and fullname like '%" & txtsearch.Text & "%'")
        LoadCTC(DataGridView1, "CTC")
    End Sub
End Class