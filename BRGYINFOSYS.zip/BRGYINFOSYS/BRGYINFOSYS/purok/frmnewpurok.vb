﻿Public Class frmnewpurok

    Private Sub frmnewpurok_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
      
    End Sub

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)


    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        If txtprkname.Text = "" Then

            ErrorProvider1.SetError(txtprkname, "Purok Name is Required!")
        Else
            If btnsave.Text = "Save" Then
                sql = "INSERT INTO `tblpurok` (`PRKNAME`) VALUES(@PRKNAME);"

                issucess = SavePurok("SaveOnly", sql)

                If issucess = True Then
                    MsgBox("New Purok has been added!")
                Else
                    MsgBox("No Purok has been added!")
                End If

            Else
                sql = "UPDATE `tblpurok` SET `PRKNAME` = @PRKNAME WHERE `tblpurok`.`PRKID` = @PRKID ;"

                issucess = SavePurok("UpdateOnly", sql)

                If issucess = True Then
                    MsgBox("New Purok has been updated!")
                Else
                    MsgBox("No Purok has been updated!")
                End If

               
            End If
            jokenfindthis("Select * from tblpurok")
            LoadPurok(frmPurok.DataGridView1, "Purok")
            frmPurok.BringToFront()

            Me.Close()
        End If

        

    End Sub
End Class