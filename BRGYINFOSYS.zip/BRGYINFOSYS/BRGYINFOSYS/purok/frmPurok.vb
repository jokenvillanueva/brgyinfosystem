﻿Public Class frmPurok

    Private Sub frmPurok_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        jokenfindthis("Select * from tblpurok")
        LoadPurok(DataGridView1, "Purok")
    End Sub

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        frmnewpurok.Show()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        With frmnewpurok
            GLOBALid = DataGridView1.CurrentRow.Cells(0).Value
            .txtprkname.Text = DataGridView1.CurrentRow.Cells(1).Value
            .Lblsupliertitle.Text = "Edit Purok"
            .btnsave.Text = "Update"

            .Show()

        End With
    End Sub
End Class