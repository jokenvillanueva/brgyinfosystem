﻿Module prurokcontroller

    Dim sex As String = "Male"
    Public Function SavePurok(ByVal saving As String, ByVal sqlstring As String) As Boolean
        Try

            If saving = "SaveOnly" Then
                sql = sqlstring
            ElseIf saving = "UpdateOnly" Then
                sql = sqlstring

            End If
            con.Open()
            cmd.Connection = con
            cmd.CommandText = sql
            With frmnewpurok
                If saving = "SaveOnly" Then

                    cmd.Parameters.AddWithValue("@PRKNAME", .txtprkname.Text)
                ElseIf saving = "UpdateOnly" Then
                    cmd.Parameters.AddWithValue("@PRKNAME", .txtprkname.Text)
                    cmd.Parameters.AddWithValue("@PRKID", GLOBALid)

                End If

            End With
            result = cmd.ExecuteNonQuery
            If result > 0 Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            cmd.Parameters.Clear()
            cmd.Dispose()
            con.Close()

        End Try
    End Function

    Public Sub LoadPurok(ByVal obj As Object, ByVal param As String)
        Try
            con.Open()
            dReader = cmd.ExecuteReader()
            '  obj.Rows.Clear()
            Select Case param
                Case "Purok"
                    obj.Rows.Clear()
                    Do While dReader.Read = True
                        obj.Rows.Add(dReader(0), dReader(1))

                    Loop
            End Select
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            da.Dispose()
            con.Close()
        End Try
    End Sub




End Module
