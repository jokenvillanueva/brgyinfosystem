﻿Public Class frmhousehold

    Private Sub frmhousehold_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        jokenfindthis("Select * from tblresidence")
        LoadHousehold(DataGridView1, "Household")
    End Sub

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click

        frmnewHousehold.Show()

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        With frmnewHousehold
            GLOBALid = DataGridView1.CurrentRow.Cells(0).Value

            jokenfindthis("SELECT * FROM tblresidence WHERE RESIDENCEID=" & GLOBALid & "")
            loadsingleHousehold("household")

            .Lblsupliertitle.Text = "Edit Household Information"
            .btnsave.Text = "Update"
            .Show()

        End With

    End Sub

    Private Sub txtsearch_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtsearch.TextChanged
        jokenfindthis("SELECT * FROM tblresidence WHERE LNAME LIKE '%" & txtsearch.Text & "%'")
        LoadHousehold(DataGridView1, "Household")
    End Sub

    Private Sub BTNUSE_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTNUSE.Click
        If CLEARANCE = "BRGY" Then
            With frmnewBrgyClearance
                GLOBALid = DataGridView1.CurrentRow.Cells(0).Value

                jokenfindthis("SELECT * FROM tblresidence WHERE RESIDENCEID=" & GLOBALid & "")
                loadsingleHousehold("household")

                .Show()

            End With
            Me.Close()
        ElseIf CLEARANCE = "BUS" Then
            With frmnewbusiness
                GLOBALid = DataGridView1.CurrentRow.Cells(0).Value

                jokenfindthis("SELECT * FROM tblresidence WHERE RESIDENCEID=" & GLOBALid & "")
                loadsingleHousehold("household")

                .Show()

            End With
            Me.Close()
        ElseIf CLEARANCE = "CTC" Then
            With frmnewctc
                GLOBALid = DataGridView1.CurrentRow.Cells(0).Value

                jokenfindthis("SELECT * FROM tblresidence WHERE RESIDENCEID=" & GLOBALid & "")
                loadsingleHousehold("household")

                .Show()

            End With
            Me.Close()
        ElseIf CLEARANCE = "BLOTTER" Then
            With frmnewblotter
                GLOBALid = DataGridView1.CurrentRow.Cells(0).Value

                jokenfindthis("SELECT * FROM tblresidence WHERE RESIDENCEID=" & GLOBALid & "")
                loadsingleHousehold("household")

                .Show()

            End With
            Me.Close()
        End If
       
    End Sub
End Class