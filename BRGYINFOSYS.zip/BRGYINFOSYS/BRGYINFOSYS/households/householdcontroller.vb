﻿Module householdcontroller
    Dim sex As String = "Male"
    Public Function SaveHousehold(ByVal saving As String, ByVal sqlstring As String) As Boolean

        Try


            If saving = "SaveOnly" Then
                sql = sqlstring
            ElseIf saving = "UpdateOnly" Then
                sql = sqlstring

            End If
            con.Open()
            cmd.Connection = con
            cmd.CommandText = sql
            With frmnewHousehold
                If saving = "SaveOnly" Then
                    ' " VALUES (@LNAME, @FNAME, @MNAME, @ext, @NO, @STREET, " & _
                    ' " @PRK, @POB, @DOB, @SEX, @CIVIL, @CITIZENSHIP, @OCCUPATION);"

                    If .RadFemale.Checked = True Then
                        .Radmale.Checked = False
                        sex = "Female"
                    End If
                    If .Radmale.Checked = True Then
                        .RadFemale.Checked = False
                        sex = "Male"
                    End If
                    cmd.Parameters.AddWithValue("@LNAME", .txtlname.Text)
                    cmd.Parameters.AddWithValue("@FNAME", .txtfname.Text)
                    cmd.Parameters.AddWithValue("@MNAME", .txtmname.Text)
                    cmd.Parameters.AddWithValue("@ext", .txtext.Text)
                    cmd.Parameters.AddWithValue("@NO", .txtno.Text)
                    cmd.Parameters.AddWithValue("@STREET", .txtstreet.Text)
                    cmd.Parameters.AddWithValue("@PRK", .cbpurok.SelectedValue)
                    cmd.Parameters.AddWithValue("@POB", .txtpob.Text)
                    cmd.Parameters.AddWithValue("@DOB", Format(.DTPpick.Value, "yyyy-MM-dd"))
                    cmd.Parameters.AddWithValue("@SEX", sex)
                    cmd.Parameters.AddWithValue("@CIVIL", .cbcivil.SelectedValue)
                    cmd.Parameters.AddWithValue("@CITIZENSHIP", .txtcitizenship.Text)
                    cmd.Parameters.AddWithValue("@OCCUPATION", .txtoccupation.Text)





                ElseIf saving = "UpdateOnly" Then
                    cmd.Parameters.AddWithValue("@LNAME", .txtlname.Text)
                    cmd.Parameters.AddWithValue("@FNAME", .txtfname.Text)
                    cmd.Parameters.AddWithValue("@MNAME", .txtmname.Text)
                    cmd.Parameters.AddWithValue("@ext", .txtext.Text)
                    cmd.Parameters.AddWithValue("@NO", .txtno.Text)
                    cmd.Parameters.AddWithValue("@STREET", .txtstreet.Text)
                    cmd.Parameters.AddWithValue("@PRK", .cbpurok.SelectedValue)
                    cmd.Parameters.AddWithValue("@POB", .txtpob.Text)
                    cmd.Parameters.AddWithValue("@DOB", Format(.DTPpick.Value, "yyyy-MM-dd"))
                    cmd.Parameters.AddWithValue("@SEX", sex)
                    cmd.Parameters.AddWithValue("@CIVIL", .cbcivil.SelectedValue)
                    cmd.Parameters.AddWithValue("@CITIZENSHIP", .txtcitizenship.Text)
                    cmd.Parameters.AddWithValue("@OCCUPATION", .txtoccupation.Text)
                    cmd.Parameters.AddWithValue("@RESIDENCEID", GLOBALid)

                End If

            End With
            result = cmd.ExecuteNonQuery
            If result > 0 Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            cmd.Parameters.Clear()
            cmd.Dispose()
            con.Close()

        End Try
    End Function

    Public Sub LoadHousehold(ByVal obj As Object, ByVal param As String)
        Try
            con.Open()
            dReader = cmd.ExecuteReader()
            '  obj.Rows.Clear()
            Select Case param
                Case "Household"
                    obj.Rows.Clear()
                    Do While dReader.Read = True
                        obj.Rows.Add(dReader(0), dReader(1), dReader(2), dReader(3), dReader(4), dReader(5), dReader(6), dReader(7), dReader(8), dReader(9), dReader(10), dReader(11), dReader(12), dReader(13))

                    Loop
            End Select
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            da.Dispose()
            con.Close()
        End Try
    End Sub



    Public Sub loadsingleHousehold(ByVal param As String)
        Try
            con.Open()
            dReader = cmd.ExecuteReader()
            '  obj.Rows.Clear()
            Select Case param
                Case "household"
                    Do While dReader.Read = True
                        ' If dReader("Numresult") = 1 Then
                        LNAME = dReader("LNAME")
                        FNAME = dReader("FNAME")
                        MNAME = dReader("MNAME")
                        ext = dReader("ext")
                        NO = dReader("NO")
                        STREET = dReader("STREET")
                        PRK = dReader("PRK")
                        POB = dReader("POB")
                        DOB = dReader("DOB")
                        sex = dReader("sex")
                        CIVIL = dReader("CIVIL")
                        CITIZENSHIP = dReader("CITIZENSHIP")
                        OCCUPATION = dReader("OCCUPATION")
                        If CLEARANCE = "BRGY" Then
                            With frmnewBrgyClearance
                                .Text = dReader("RESIDENCEID")
                                .txtlname.Text = LNAME & ", " & FNAME & " " & MNAME
                                .TXTGENDER.Text = sex
                                .TXTAGE.Text = DateDiff(DateInterval.Year, dReader("DOB"), Now.Date)
                                .TXTCIVIL.Text = CIVIL
                                .TXTADDRESS.Text = NO & " " & STREET & " " & PRK

                            End With
                        ElseIf CLEARANCE = "BUS" Then
                            With frmnewbusiness
                                .Text = dReader("RESIDENCEID")
                                .txtlname.Text = LNAME & ", " & FNAME & " " & MNAME

                            End With
                        ElseIf CLEARANCE = "CTC" Then
                            With frmnewctc
                                .lblresid.Text = dReader("RESIDENCEID")
                                .txtlname.Text = LNAME & ", " & FNAME & " " & MNAME
                                .TXTGENDER.Text = sex
                                .TXTCIVIL.Text = CIVIL
                                .TXTADDRESS.Text = NO & " " & STREET & " " & " " & PRK & " Barangay Uno, Katipunan, Zamboanga del Norte"
                                .txtpob.Text = POB
                                .DTPpick.Value = DOB
                            End With
                        ElseIf CLEARANCE = "BLOTTER" Then
                            With frmnewblotter
                                .lblresid.Text = dReader("RESIDENCEID")
                                .txtlname.Text = LNAME & ", " & FNAME & " " & MNAME
                                .TXTADDRESS.Text = NO & " " & STREET & " " & " " & PRK & " Barangay Uno, Katipunan, Zamboanga del Norte"

                            End With
                        Else
                            With frmnewHousehold
                                .txtlname.Text = LNAME
                                .txtfname.Text = FNAME
                                .txtmname.Text = MNAME
                                .txtext.Text = ext
                                .txtno.Text = NO
                                .txtstreet.Text = STREET
                                .cbpurok.Text = PRK
                                .txtpob.Text = POB
                                .DTPpick.Value = DOB
                                If sex = "Male" Then
                                    .Radmale.Checked = True
                                    .RadFemale.Checked = False
                                End If

                                If sex = "Female" Then
                                    .Radmale.Checked = False
                                    .RadFemale.Checked = True
                                End If
                                .cbcivil.Text = CIVIL
                                .txtcitizenship.Text = CITIZENSHIP
                                .txtoccupation.Text = OCCUPATION


                            End With
                        End If
                      
                        ' End If

                    Loop
            End Select
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            da.Dispose()
            con.Close()
        End Try
    End Sub
End Module
