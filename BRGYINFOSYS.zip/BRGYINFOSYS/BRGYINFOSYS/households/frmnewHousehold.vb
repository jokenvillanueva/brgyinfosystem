﻿Public Class frmnewHousehold

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click


        If btnsave.Text = "Save" Then
            sql = "INSERT INTO `tblresidence` (`LNAME`, `FNAME`, `MNAME`, `ext`, `NO`, `STREET`, " & _
                                                " `PRK`, `POB`, `DOB`, `SEX`, `CIVIL`, `CITIZENSHIP`, `OCCUPATION`) " & _
                                                " VALUES (@LNAME, @FNAME, @MNAME, @ext, @NO, @STREET, " & _
                                                 " @PRK, @POB, @DOB, @SEX, @CIVIL, @CITIZENSHIP, @OCCUPATION);"

            issucess = SaveHousehold("SaveOnly", sql)

            If issucess = True Then
                MsgBox("New Household has been added!")
            Else
                MsgBox("No Household has been added!")
            End If

            jokenfindthis("Select * from tblresidence")
            LoadHousehold(frmhousehold.DataGridView1, "Household")
            Me.Close()
        Else
            sql = "UPDATE `tblresidence` SET `LNAME` = @LNAME, `FNAME` = @FNAME, `MNAME` = @MNAME, " & _
                    "`ext` = @ext, `NO` = @NO, `STREET` = @STREET, `PRK` = @PRK, `POB` = @POB, " & _
                    " `DOB` = @DOB, `SEX` = @SEX, `CIVIL` = @CIVIL, `CITIZENSHIP` = @CITIZENSHIP, " & _
                    " `OCCUPATION` = @OCCUPATION WHERE `tblresidence`.`RESIDENCEID` = @RESIDENCEID;"

            issucess = SaveHousehold("UpdateOnly", sql)

            If issucess = True Then
                MsgBox("New Household has been updated!")
            Else
                MsgBox("No Household has been updated!")
            End If

            jokenfindthis("Select * from tblresidence")
            LoadHousehold(frmhousehold.DataGridView1, "Household")
            Me.Close()

        End If
    End Sub

    Private Sub frmnewHousehold_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        jokenfindthis("Select * from tblpurok")
        fillcombo(cbpurok, "PRKNAME", "PRKNAME")
    End Sub
End Class