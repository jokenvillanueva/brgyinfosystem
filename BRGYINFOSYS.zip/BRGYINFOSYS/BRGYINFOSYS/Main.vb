﻿Public Class Main

    Private Sub tlshousehold_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tlshousehold.Click
        frmhousehold.Show()

    End Sub

    Private Sub tlsGradelvel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tlsPurok.Click
        frmPurok.Show()

    End Sub

    Private Sub tlsSMSlogs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tlsbrgycl.Click
        frmbrgyClearance.Show()

    End Sub

    Private Sub manageUsersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles manageUsersToolStripMenuItem.Click
        uselist.Show()

    End Sub

    Private Sub tlsStudent_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tlsofficials.Click
        uselist.Show()
    End Sub

    Private Sub TLlogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TLlogin.Click
        If TLlogin.Text = "Login" Then
            LoginForm1.Show()
        Else
            TLlogin.Text = "Login"
            TSUser.Text = "Default user"
            Visible_Button(False)

        End If
    End Sub

    Private Sub Main_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Visible_Button(False)
    End Sub

    Private Sub ToolStripButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton1.Click
        frmbusiness.Show()

    End Sub

    Private Sub tlsBroadcast_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tlsBroadcast.Click
        frmctc.Show()

    End Sub

    Private Sub ToolStripButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton2.Click
        frmcomplain.Show()

    End Sub

    Private Sub tlsDTR_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tlsDTR.Click
        frmblotter.Show()

    End Sub
End Class
