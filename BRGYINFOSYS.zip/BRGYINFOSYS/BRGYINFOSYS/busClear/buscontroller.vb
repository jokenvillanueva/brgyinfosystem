﻿Module buscontroller
    Public Function SaveBusinessClearance(ByVal saving As String, ByVal sqlstring As String) As Boolean

        Try


            If saving = "SaveOnly" Then
                sql = sqlstring
            ElseIf saving = "UpdateOnly" Then
                sql = sqlstring

            End If
            con.Open()
            cmd.Connection = con
            cmd.CommandText = sql
            With frmnewbusiness
                If saving = "SaveOnly" Then
                    '"INSERT INTO `tblbrgytax` ( `RESID`, `FULLNAME`, `BUSINAME`, `KINDOFBUS`, `NATUREOFBUS`, " & _
                    '" `RESCERTNO`, `ISSUEDON`, `ISSUEDAT`, `ORNUM`, `ORISSUEDON`, `ORISSUEDONAT`, `TIN`, `CAPTAIN`, LOCATION) " & _
                    '" VALUES (@RESID, @FULLNAME, @BUSINAME, @KINDOFBUS, @NATUREOFBUS, @RESCERTNO, @ISSUEDON, @ISSUEDAT, @ORNUM, " & _
                    '" @ORISSUEDON, @ORISSUEDONAT, @TIN, @CAPTAIN, @LOCATION)"

                    cmd.Parameters.AddWithValue("@RESID", Val(.Text))
                    cmd.Parameters.AddWithValue("@FULLNAME", .txtlname.Text)
                    cmd.Parameters.AddWithValue("@BUSINAME", .TXTBUSNAME.Text)
                    cmd.Parameters.AddWithValue("@KINDOFBUS", .TXTKIND.Text)
                    cmd.Parameters.AddWithValue("@NATUREOFBUS", .TXTNATURE.Text)
                    cmd.Parameters.AddWithValue("@RESCERTNO", Val(.txtresno.Text))
                    cmd.Parameters.AddWithValue("@ISSUEDON", Format(.dtRissued.Value, "yyyy-MM-dd"))
                    cmd.Parameters.AddWithValue("@ISSUEDAT", .txtresIssAt.Text)
                    cmd.Parameters.AddWithValue("@ORNUM", Val(.TXTOR.Text))
                    cmd.Parameters.AddWithValue("@ORISSUEDON", Format(.dtIssued.Value, "yyyy-MM-dd"))
                    cmd.Parameters.AddWithValue("@ORISSUEDONAT", .txtissuedat.Text)
                    cmd.Parameters.AddWithValue("@TIN", Val(.TXTTIN.Text))
                    cmd.Parameters.AddWithValue("@CAPTAIN", .txtCaptain.Text)
                    cmd.Parameters.AddWithValue("@LOCATION", .TXTLOCATION.Text)

                ElseIf saving = "UpdateOnly" Then
                    cmd.Parameters.AddWithValue("@RESID", Val(.lblresid.Text))
                    cmd.Parameters.AddWithValue("@FULLNAME", .txtlname.Text)
                    cmd.Parameters.AddWithValue("@BUSINAME", .TXTBUSNAME.Text)
                    cmd.Parameters.AddWithValue("@KINDOFBUS", .TXTKIND.Text)
                    cmd.Parameters.AddWithValue("@NATUREOFBUS", .TXTNATURE.Text)
                    cmd.Parameters.AddWithValue("@RESCERTNO", Val(.txtresno.Text))
                    cmd.Parameters.AddWithValue("@ISSUEDON", Format(.dtRissued.Value, "yyyy-MM-dd"))
                    cmd.Parameters.AddWithValue("@ISSUEDAT", .txtresIssAt.Text)
                    cmd.Parameters.AddWithValue("@ORNUM", Val(.TXTOR.Text))
                    cmd.Parameters.AddWithValue("@ORISSUEDON", Format(.dtIssued.Value, "yyyy-MM-dd"))
                    cmd.Parameters.AddWithValue("@ORISSUEDONAT", .txtissuedat.Text)
                    cmd.Parameters.AddWithValue("@TIN", Val(.TXTTIN.Text))
                    cmd.Parameters.AddWithValue("@CAPTAIN", .txtCaptain.Text)
                    cmd.Parameters.AddWithValue("@LOCATION", .TXTLOCATION.Text)
                    cmd.Parameters.AddWithValue("@ID", .Text)

                End If

            End With
            result = cmd.ExecuteNonQuery
            If result > 0 Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            cmd.Parameters.Clear()
            cmd.Dispose()
            con.Close()

        End Try
    End Function

    Public Sub LoadBusinessClearance(ByVal obj As Object, ByVal param As String)
        Try
            con.Open()
            dReader = cmd.ExecuteReader()
            '  obj.Rows.Clear()
            Select Case param
                Case "bus"
                    obj.Rows.Clear()
                    Do While dReader.Read = True

                        obj.Rows.Add(dReader(0), dReader(1), dReader(2), dReader(3), dReader(4), dReader(5), dReader(6), dReader(7), dReader(8), dReader(9), dReader(10), dReader(11), dReader(12), dReader(13), dReader(14))

                    Loop
            End Select
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            da.Dispose()
            con.Close()
        End Try
    End Sub
  
    Public Sub loadsingleBusiness(ByVal param As String)
        Try
            con.Open()
            dReader = cmd.ExecuteReader()
            '  obj.Rows.Clear()
            Select Case param
                Case "BUS"
                    Do While dReader.Read = True
                        With frmnewbusiness
                            .Text = dReader("ID")
                            .lblresid.Text = dReader("RESID")
                            .txtlname.Text = dReader("FULLNAME")
                            .TXTBUSNAME.Text = dReader("BUSINAME")
                            .TXTKIND.Text = dReader("KINDOFBUS")
                            .TXTNATURE.Text = dReader("NATUREOFBUS")
                            .txtresno.Text = dReader("RESCERTNO")
                            .dtRissued.Value = Format(dReader("ISSUEDON"), "yyyy-MM-dd")
                            .txtresIssAt.Text = dReader("ISSUEDAT")
                            .TXTOR.Text = dReader("ORNUM")
                            .dtIssued.Value = Format(dReader("ORISSUEDON"), "yyyy-MM-dd")
                            .txtissuedat.Text = dReader("ORISSUEDONAT")
                            .TXTTIN.Text = dReader("TIN")
                            .txtCaptain.Text = dReader("CAPTAIN")
                            .TXTLOCATION.Text = dReader("LOCATION")

                           
                        End With
                    Loop

            End Select
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            da.Dispose()
            con.Close()
        End Try
    End Sub
End Module
