﻿Public Class frmbusiness

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        jokenfindthis("SELECT * FROM `tblemployee` WHERE `EMPPOSITION` ='CAPTAIN' AND `ACCSTATUS` ='YES'")
        loadsinglECaptain("captain", "BUS")
        frmnewbusiness.Show()
    End Sub

    Private Sub frmbusiness_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        jokenfindthis("SELECT * FROM `tblbrgytax`")
        LoadBusinessClearance(DataGridView1, "bus")

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        With frmnewbusiness
            GLOBALid = DataGridView1.CurrentRow.Cells(0).Value

            jokenfindthis("SELECT * FROM `tblbrgytax` where ID=" & GLOBALid & "")
            loadsingleBusiness("BUS")

            .Lblsupliertitle.Text = "Edit Brgy. Bus. Tax Clearance"
            .btnsave.Text = "Update"
            .btnsearch.Enabled = False

            .Show()

        End With
    End Sub

    Private Sub txtsearch_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtsearch.TextChanged
        jokenfindthis("SELECT * FROM `tblbrgytax` where FULLNAME LIKE '%" & txtsearch.Text & "%'")
        LoadBusinessClearance(DataGridView1, "bus")
    End Sub
End Class