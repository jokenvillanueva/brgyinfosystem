﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmnewbusiness
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TXTOR = New System.Windows.Forms.TextBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.txtCaptain = New System.Windows.Forms.TextBox
        Me.brgycaptain = New System.Windows.Forms.Label
        Me.TXTBUSNAME = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.txtlname = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtresno = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtresIssAt = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.dtIssued = New System.Windows.Forms.DateTimePicker
        Me.dtRissued = New System.Windows.Forms.DateTimePicker
        Me.txtissuedat = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.btnsave = New System.Windows.Forms.Button
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Lblsupliertitle = New System.Windows.Forms.Label
        Me.TXTKIND = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.TXTNATURE = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.TXTTIN = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.btnsearch = New System.Windows.Forms.Button
        Me.TXTLOCATION = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.lblresid = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'TXTOR
        '
        Me.TXTOR.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TXTOR.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TXTOR.BackColor = System.Drawing.SystemColors.HighlightText
        Me.TXTOR.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXTOR.Location = New System.Drawing.Point(146, 256)
        Me.TXTOR.Name = "TXTOR"
        Me.TXTOR.Size = New System.Drawing.Size(197, 22)
        Me.TXTOR.TabIndex = 65
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lblresid)
        Me.GroupBox1.Controls.Add(Me.TXTLOCATION)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtCaptain)
        Me.GroupBox1.Controls.Add(Me.brgycaptain)
        Me.GroupBox1.Controls.Add(Me.TXTTIN)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.dtIssued)
        Me.GroupBox1.Controls.Add(Me.txtissuedat)
        Me.GroupBox1.Controls.Add(Me.TXTNATURE)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.dtRissued)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.TXTOR)
        Me.GroupBox1.Controls.Add(Me.TXTKIND)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.txtresIssAt)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.txtresno)
        Me.GroupBox1.Controls.Add(Me.TXTBUSNAME)
        Me.GroupBox1.Controls.Add(Me.btnsearch)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.txtlname)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 62)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(462, 406)
        Me.GroupBox1.TabIndex = 37
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Details"
        '
        'txtCaptain
        '
        Me.txtCaptain.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtCaptain.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtCaptain.BackColor = System.Drawing.SystemColors.HighlightText
        Me.txtCaptain.Enabled = False
        Me.txtCaptain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCaptain.Location = New System.Drawing.Point(146, 368)
        Me.txtCaptain.Name = "txtCaptain"
        Me.txtCaptain.Size = New System.Drawing.Size(196, 22)
        Me.txtCaptain.TabIndex = 60
        '
        'brgycaptain
        '
        Me.brgycaptain.AutoSize = True
        Me.brgycaptain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.brgycaptain.Location = New System.Drawing.Point(41, 374)
        Me.brgycaptain.Name = "brgycaptain"
        Me.brgycaptain.Size = New System.Drawing.Size(94, 16)
        Me.brgycaptain.TabIndex = 59
        Me.brgycaptain.Text = "Brgy. Captain :"
        '
        'TXTBUSNAME
        '
        Me.TXTBUSNAME.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TXTBUSNAME.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TXTBUSNAME.BackColor = System.Drawing.SystemColors.HighlightText
        Me.TXTBUSNAME.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXTBUSNAME.Location = New System.Drawing.Point(146, 61)
        Me.TXTBUSNAME.Name = "TXTBUSNAME"
        Me.TXTBUSNAME.Size = New System.Drawing.Size(197, 22)
        Me.TXTBUSNAME.TabIndex = 48
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(71, 37)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(69, 16)
        Me.Label15.TabIndex = 28
        Me.Label15.Text = "Fullname :"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(34, 67)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(106, 16)
        Me.Label11.TabIndex = 21
        Me.Label11.Text = "Business name :"
        '
        'txtlname
        '
        Me.txtlname.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtlname.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtlname.BackColor = System.Drawing.SystemColors.HighlightText
        Me.txtlname.Enabled = False
        Me.txtlname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtlname.Location = New System.Drawing.Point(146, 31)
        Me.txtlname.Name = "txtlname"
        Me.txtlname.Size = New System.Drawing.Size(197, 22)
        Me.txtlname.TabIndex = 1
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(41, 180)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(96, 16)
        Me.Label5.TabIndex = 61
        Me.Label5.Text = "Res. Cert. No. :"
        '
        'txtresno
        '
        Me.txtresno.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtresno.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtresno.BackColor = System.Drawing.SystemColors.HighlightText
        Me.txtresno.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtresno.Location = New System.Drawing.Point(146, 174)
        Me.txtresno.Name = "txtresno"
        Me.txtresno.Size = New System.Drawing.Size(197, 22)
        Me.txtresno.TabIndex = 62
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(61, 206)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(74, 16)
        Me.Label6.TabIndex = 63
        Me.Label6.Text = "Issued On :"
        '
        'txtresIssAt
        '
        Me.txtresIssAt.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtresIssAt.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtresIssAt.BackColor = System.Drawing.SystemColors.HighlightText
        Me.txtresIssAt.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtresIssAt.Location = New System.Drawing.Point(146, 228)
        Me.txtresIssAt.Name = "txtresIssAt"
        Me.txtresIssAt.Size = New System.Drawing.Size(197, 22)
        Me.txtresIssAt.TabIndex = 64
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(66, 234)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(69, 16)
        Me.Label7.TabIndex = 65
        Me.Label7.Text = "Issued At :"
        '
        'dtIssued
        '
        Me.dtIssued.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtIssued.Location = New System.Drawing.Point(146, 286)
        Me.dtIssued.Name = "dtIssued"
        Me.dtIssued.Size = New System.Drawing.Size(197, 20)
        Me.dtIssued.TabIndex = 72
        '
        'dtRissued
        '
        Me.dtRissued.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtRissued.Location = New System.Drawing.Point(146, 202)
        Me.dtRissued.Name = "dtRissued"
        Me.dtRissued.Size = New System.Drawing.Size(197, 20)
        Me.dtRissued.TabIndex = 61
        '
        'txtissuedat
        '
        Me.txtissuedat.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtissuedat.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtissuedat.BackColor = System.Drawing.SystemColors.HighlightText
        Me.txtissuedat.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtissuedat.Location = New System.Drawing.Point(147, 312)
        Me.txtissuedat.Name = "txtissuedat"
        Me.txtissuedat.Size = New System.Drawing.Size(196, 22)
        Me.txtissuedat.TabIndex = 67
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(67, 318)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(69, 16)
        Me.Label8.TabIndex = 71
        Me.Label8.Text = "Issued At :"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(51, 262)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(85, 16)
        Me.Label13.TabIndex = 25
        Me.Label13.Text = "OR Number :"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(62, 290)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(74, 16)
        Me.Label9.TabIndex = 69
        Me.Label9.Text = "Issued On :"
        '
        'btnsave
        '
        Me.btnsave.Location = New System.Drawing.Point(139, 474)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(159, 39)
        Me.btnsave.TabIndex = 40
        Me.btnsave.Text = "Save"
        Me.btnsave.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.Highlight
        Me.Panel2.Controls.Add(Me.Lblsupliertitle)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(496, 60)
        Me.Panel2.TabIndex = 38
        '
        'Lblsupliertitle
        '
        Me.Lblsupliertitle.AutoSize = True
        Me.Lblsupliertitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblsupliertitle.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Lblsupliertitle.Location = New System.Drawing.Point(17, 20)
        Me.Lblsupliertitle.Name = "Lblsupliertitle"
        Me.Lblsupliertitle.Size = New System.Drawing.Size(434, 25)
        Me.Lblsupliertitle.TabIndex = 0
        Me.Lblsupliertitle.Text = "New Brgy. BUSINESS TAX CLEARANCE"
        '
        'TXTKIND
        '
        Me.TXTKIND.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TXTKIND.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TXTKIND.BackColor = System.Drawing.SystemColors.HighlightText
        Me.TXTKIND.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXTKIND.Location = New System.Drawing.Point(146, 89)
        Me.TXTKIND.Name = "TXTKIND"
        Me.TXTKIND.Size = New System.Drawing.Size(197, 22)
        Me.TXTKIND.TabIndex = 62
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(28, 95)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(112, 16)
        Me.Label1.TabIndex = 61
        Me.Label1.Text = "Kind of Business :"
        '
        'TXTNATURE
        '
        Me.TXTNATURE.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TXTNATURE.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TXTNATURE.BackColor = System.Drawing.SystemColors.HighlightText
        Me.TXTNATURE.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXTNATURE.Location = New System.Drawing.Point(146, 117)
        Me.TXTNATURE.Name = "TXTNATURE"
        Me.TXTNATURE.Size = New System.Drawing.Size(197, 22)
        Me.TXTNATURE.TabIndex = 64
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(11, 123)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(126, 16)
        Me.Label12.TabIndex = 63
        Me.Label12.Text = "Nature of Business :"
        '
        'TXTTIN
        '
        Me.TXTTIN.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TXTTIN.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TXTTIN.BackColor = System.Drawing.SystemColors.HighlightText
        Me.TXTTIN.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXTTIN.Location = New System.Drawing.Point(146, 340)
        Me.TXTTIN.Name = "TXTTIN"
        Me.TXTTIN.Size = New System.Drawing.Size(196, 22)
        Me.TXTTIN.TabIndex = 73
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(100, 346)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(36, 16)
        Me.Label2.TabIndex = 74
        Me.Label2.Text = "TIN :"
        '
        'btnsearch
        '
        Me.btnsearch.Location = New System.Drawing.Point(349, 30)
        Me.btnsearch.Name = "btnsearch"
        Me.btnsearch.Size = New System.Drawing.Size(52, 23)
        Me.btnsearch.TabIndex = 1
        Me.btnsearch.Text = "Search"
        Me.btnsearch.UseVisualStyleBackColor = True
        '
        'TXTLOCATION
        '
        Me.TXTLOCATION.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TXTLOCATION.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TXTLOCATION.BackColor = System.Drawing.SystemColors.HighlightText
        Me.TXTLOCATION.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXTLOCATION.Location = New System.Drawing.Point(145, 146)
        Me.TXTLOCATION.Name = "TXTLOCATION"
        Me.TXTLOCATION.Size = New System.Drawing.Size(197, 22)
        Me.TXTLOCATION.TabIndex = 76
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(75, 152)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 16)
        Me.Label3.TabIndex = 75
        Me.Label3.Text = "Location :"
        '
        'lblresid
        '
        Me.lblresid.AutoSize = True
        Me.lblresid.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblresid.Location = New System.Drawing.Point(144, 12)
        Me.lblresid.Name = "lblresid"
        Me.lblresid.Size = New System.Drawing.Size(69, 16)
        Me.lblresid.TabIndex = 77
        Me.lblresid.Text = "Fullname :"
        Me.lblresid.Visible = False
        '
        'frmnewbusiness
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(496, 522)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnsave)
        Me.Controls.Add(Me.Panel2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "frmnewbusiness"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TXTOR As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtCaptain As System.Windows.Forms.TextBox
    Friend WithEvents brgycaptain As System.Windows.Forms.Label
    Friend WithEvents TXTBUSNAME As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtlname As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtresno As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtresIssAt As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents dtIssued As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtRissued As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtissuedat As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents btnsave As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Lblsupliertitle As System.Windows.Forms.Label
    Friend WithEvents TXTNATURE As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents TXTKIND As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TXTTIN As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnsearch As System.Windows.Forms.Button
    Friend WithEvents TXTLOCATION As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lblresid As System.Windows.Forms.Label
End Class
