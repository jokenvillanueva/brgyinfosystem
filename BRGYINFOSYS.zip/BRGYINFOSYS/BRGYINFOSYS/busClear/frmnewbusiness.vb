﻿Public Class frmnewbusiness

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        If btnsave.Text = "Save" Then
            sql = "INSERT INTO `tblbrgytax` ( `RESID`, `FULLNAME`, `BUSINAME`, `KINDOFBUS`, `NATUREOFBUS`, " & _
            " `RESCERTNO`, `ISSUEDON`, `ISSUEDAT`, `ORNUM`, `ORISSUEDON`, `ORISSUEDONAT`, `TIN`, `CAPTAIN`, LOCATION) " & _
            " VALUES (@RESID, @FULLNAME, @BUSINAME, @KINDOFBUS, @NATUREOFBUS, @RESCERTNO, @ISSUEDON, @ISSUEDAT, @ORNUM, " & _
            " @ORISSUEDON, @ORISSUEDONAT, @TIN, @CAPTAIN, @LOCATION)"


            issucess = SaveBusinessClearance("SaveOnly", sql)

            If issucess = True Then
                MsgBox("New Business Tax Clearance has been added!")
            Else
                MsgBox("No Business Tax Clearance has been added!")
            End If

            jokenfindthis("Select * from tblresidence")
            LoadHousehold(frmhousehold.DataGridView1, "Household")
            Me.Close()
        Else
            sql = "UPDATE `tblbrgytax` SET `RESID` = @RESID, `FULLNAME` =@FULLNAME, `BUSINAME` = @BUSINAME, `KINDOFBUS` = @KINDOFBUS, " & _
                " `NATUREOFBUS` = @NATUREOFBUS, `RESCERTNO` = @RESCERTNO, `ISSUEDON` = @ISSUEDON, `ISSUEDAT` = @ISSUEDAT, `ORNUM` = @ORNUM, " & _
                " `ORISSUEDON` = @ORISSUEDON, `ORISSUEDONAT` = @ORISSUEDONAT, `TIN` = @TIN, `LOCATION` = @LOCATION WHERE `tblbrgytax`.`ID` = @ID;"

            issucess = SaveBusinessClearance("UpdateOnly", sql)

            If issucess = True Then
                MsgBox("Business Tax Clearance has been updated!")
            Else
                MsgBox("No Business Tax Clearance has been updated!")
            End If

            jokenfindthis("Select * from tblresidence")
            LoadHousehold(frmhousehold.DataGridView1, "Household")
            Me.Close()

        End If
    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        CLEARANCE = "BUS"
        frmhousehold.Show()
    End Sub

    Private Sub frmnewbusiness_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class