﻿Public Class frmnewuser


    Dim Statactive As String = "NO"

    

    Private Sub frmnewuser_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        jokenfindthis("SELECT `COMMON_ID`,`LISTNAME`,`IS_DEFAULT` FROM `tblcommonmaster` WHERE `CATEGORY`='USERTYPE'")
        fillcombo(cbUsertype, "LISTNAME", "LISTNAME")
    End Sub
    Sub finalAction()
        uselist.Close()
        uselist.Show()
        GLOBALid = Nothing
        GLOBALMessage = ""
        ClearAll(GroupBox1, "User")
        Me.Close()
    End Sub
    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click

        If radActive.Checked = True Then
            Statactive = "YES"
        End If
        If radNotActive.Checked = True Then
            Statactive = "NO"
        End If

        If btnsave.Text = "Save" Then
            If txtsupname.Text = "" Then
                ErrorProvider1.SetError(txtsupname, "Employee Name is Required!")
                Exit Sub
            ElseIf txtuser.Text = "" Then
                ErrorProvider2.SetError(txtuser, "User Name is Required!")
                Exit Sub
            ElseIf txtpass.Text = "" Then
                ErrorProvider3.SetError(txtpass, "Password is Required!")
                Exit Sub

            Else
                jokenfindthis("SELECT count(*) FROM tblemployee WHERE USERNAME='" & txtuser.Text & "'")
                If NumRows() > 0 Then
                    MsgBox("Username ALready Registered!")
                Else




                    If txtpass.Text = txtconfirm.Text Then
                        issucess = jokeninsert("INSERT INTO `tblemployee` (`EMPNAME`, `EMPADDRESS`, `EMPCONTACT`, `EMPPOSITION`, `USERNAME`, `PASSWRD`,ACCSTATUS) " & _
                                     " VALUES ( '" & txtsupname.Text & "', '" & txtsupadd.Text & "', '" & txtsupcontact.Text & "', '" & cbUsertype.SelectedValue & "', '" & txtuser.Text & "', SHA1('" & txtpass.Text & "'), '" & Statactive & "' )")
                        GLOBALMessage = "SaveOnly"

                    Else
                        MsgBox("Confirm Password Does not Match!")
                        Exit Sub

                    End If
                End If
            End If



        Else
            If txtsupname.Text = "" Then
                ErrorProvider1.SetError(txtsupname, "Employee Name is Required!")
                Exit Sub
            ElseIf txtuser.Text = "" Then
                ErrorProvider2.SetError(txtuser, "User Name is Required!")
                Exit Sub
            ElseIf txtpass.Text = "" Then
                ErrorProvider3.SetError(txtpass, "Password is Required!")
                Exit Sub

            Else

                sql = "UPDATE `tblemployee` SET `EMPNAME` = '" & txtsupname.Text & "', `EMPADDRESS` ='" & txtsupadd.Text & "',`EMPCONTACT` ='" & txtsupcontact.Text & "', " & _
                                       "`EMPPOSITION` ='" & cbUsertype.SelectedValue & "', `USERNAME` = '" & txtuser.Text & "', `PASSWRD` = SHA1('" & txtpass.Text & "')," & _
                                        " `ACCSTATUS` = '" & Statactive & "' WHERE `EMPID` = " & GLOBALid
                issucess = jokenupdate(sql)
                GLOBALMessage = "UpdateOnly"
            End If

        End If


        If issucess = True Then
            If GLOBALMessage = "SaveOnly" Then
                MsgBox("New Employee has been successfully created!")
                finalAction()

            ElseIf GLOBALMessage = "UpdateOnly" Then
                MsgBox("Employee Information has been updated!")
                finalAction()
            End If
        Else
            If GLOBALMessage = "SaveOnly" Then
                MsgBox("No Employee has been created!")
            ElseIf GLOBALMessage = "UpdateOnly" Then
                MsgBox("No Employee has been updated!")
            End If
        End If

    End Sub
End Class