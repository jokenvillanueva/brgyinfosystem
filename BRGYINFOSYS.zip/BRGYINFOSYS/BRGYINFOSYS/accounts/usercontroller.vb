﻿Module usercontroller
    Public Function SaveUSer(ByVal saving As String, ByVal sqlstring As String) As Boolean
        Try

            If saving = "SaveOnly" Then
                sql = sqlstring
            ElseIf saving = "UpdateOnly" Then
                sql = sqlstring

            End If
            con.Open()
            cmd.Connection = con
            cmd.CommandText = sql
            With frmnewuser
                Dim Statactive As String = "NO"
                If .radActive.Checked = True Then
                    Statactive = "YES"
                End If
                If .radNotActive.Checked = True Then
                    Statactive = "YES"
                End If

                If saving = "SaveOnly" Then

                    cmd.Parameters.AddWithValue("@EMPNAME", .txtsupname.Text)
                    cmd.Parameters.AddWithValue("@EMPADDRESS", .txtsupadd.Text)
                    cmd.Parameters.AddWithValue("@EMPCONTACT", .txtsupcontact.Text)
                    cmd.Parameters.AddWithValue("@EMPPOSITION", .cbUsertype.SelectedValue)
                    cmd.Parameters.AddWithValue("@USERNAME", .txtuser.Text)
                    cmd.Parameters.AddWithValue("@PASSWRD", ("& .txtpass.Text & "))
                    cmd.Parameters.AddWithValue("@ACCSTATUS", Statactive)

                ElseIf saving = "UpdateOnly" Then

                    cmd.Parameters.AddWithValue("@EMPNAME", .txtsupname.Text)
                    cmd.Parameters.AddWithValue("@EMPADDRESS", .txtsupadd.Text)
                    cmd.Parameters.AddWithValue("@EMPCONTACT", .txtsupcontact.Text)
                    cmd.Parameters.AddWithValue("@EMPPOSITION", .cbUsertype.SelectedValue)
                    cmd.Parameters.AddWithValue("@USERNAME", .txtuser.Text)
                    cmd.Parameters.AddWithValue("@PASSWRD", "sha1(" & .txtpass.Text & ") ")
                    cmd.Parameters.AddWithValue("@ACCSTATUS", Statactive)
                    cmd.Parameters.AddWithValue("@EMPID", GLOBALid)

                End If

            End With
            result = cmd.ExecuteNonQuery
            If result > 0 Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            cmd.Parameters.Clear()
            cmd.Dispose()
            con.Close()

        End Try
    End Function

    Public Sub LoadUser(ByVal obj As Object, ByVal param As String)
        Try
            con.Open()
            dReader = cmd.ExecuteReader()
            '  obj.Rows.Clear()
            Select Case param
                Case "User"
                    obj.Rows.Clear()
                    Do While dReader.Read = True
                        obj.Rows.Add(dReader(0), dReader(1), dReader(2), dReader(3), dReader(4), dReader(5), dReader(6), dReader(6))
                    Loop

            End Select
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            da.Dispose()
            con.Close()
        End Try
    End Sub


    Public Sub loadsingleUser(ByVal param As String)
        Try
            con.Open()
            dReader = cmd.ExecuteReader()
            '  obj.Rows.Clear()
            Select Case param
                Case "login"
                    Do While dReader.Read = True
                        If dReader("Numresult") = 1 Then
                            userID = dReader("EMPID")
                            usertype = dReader("EMPPOSITION")
                            fullname = dReader("EMPNAME")

                        End If




                    Loop
            End Select
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            da.Dispose()
            con.Close()
        End Try
    End Sub
End Module
