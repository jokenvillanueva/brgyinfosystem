﻿Public Class uselist

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        frmnewuser.btnsave.Text = "Save"
        frmnewuser.Lblsupliertitle.Text = "Add New Employee"
        frmnewuser.Show()

    End Sub

    Private Sub uselist_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        jokenfindthis("SELECT `EMPID`, `EMPNAME`, `EMPADDRESS`, `EMPCONTACT`, `EMPPOSITION`, `USERNAME`, `ACCSTATUS`,`PASSWRD` FROM `tblemployee`")
        LoadUser(DataGridView1, "User")
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        With frmnewuser
            GLOBALid = DataGridView1.CurrentRow.Cells(0).Value
            .txtsupname.Text = DataGridView1.CurrentRow.Cells(1).Value
            .txtsupadd.Text = DataGridView1.CurrentRow.Cells(2).Value
            .txtsupcontact.Text = DataGridView1.CurrentRow.Cells(3).Value

            .cbUsertype.Text = DataGridView1.CurrentRow.Cells(4).Value
            .cbUsertype.SelectedValue = DataGridView1.CurrentRow.Cells(4).Value


            .txtuser.Text = DataGridView1.CurrentRow.Cells(5).Value


            If DataGridView1.CurrentRow.Cells(6).Value = "YES" Then
                .radActive.Checked = True
                .radNotActive.Checked = False
            Else
                .radActive.Checked = False
                .radNotActive.Checked = True
            End If
            .Lblsupliertitle.Text = "Edit Employee Information"
            .btnsave.Text = "Update"
            .Show()

        End With
    End Sub
End Class