﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main))
        Me.menuStrip1 = New System.Windows.Forms.MenuStrip
        Me.fileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuNewTrans = New System.Windows.Forms.ToolStripMenuItem
        Me.toolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator
        Me.logOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.closeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.settingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.changePasswordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.manageUsersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.reportsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.householdInformationReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.populationReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.religiousAffiliationReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ageBracketReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.toddlersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.toolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem
        Me.elementaryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.highShoolToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.workingAgeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.aboveSeniorCitizenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ageBracketSummaryReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.estimatedMonthlyIncomeReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.lessThan5000ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.toolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem
        Me.toolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem
        Me.toolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem
        Me.toolStripMenuItem7 = New System.Windows.Forms.ToolStripMenuItem
        Me.toolStripMenuItem8 = New System.Windows.Forms.ToolStripMenuItem
        Me.over30000ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.incomeSummaryReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.employmentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.employedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.selfEmployedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.unemployedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.employmentSummaryReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.vehicleInformationReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.genderDistributionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.maleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.femaleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.civilStatusToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.singleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.marriedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.widowWidowerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.accessoriesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.calculatorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.internetBrowserToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.taskManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.servicesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.commandLineToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.systemInformationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.helpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.aboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStrip2 = New System.Windows.Forms.ToolStrip
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.tlshousehold = New System.Windows.Forms.ToolStripButton
        Me.tlsPurok = New System.Windows.Forms.ToolStripButton
        Me.tlsofficials = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.tlsbrgycl = New System.Windows.Forms.ToolStripButton
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton
        Me.tlsBroadcast = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton2 = New System.Windows.Forms.ToolStripButton
        Me.tlsDTR = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator
        Me.tlsreports = New System.Windows.Forms.ToolStripButton
        Me.TLlogin = New System.Windows.Forms.ToolStripButton
        Me.TSUser = New System.Windows.Forms.ToolStripLabel
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.menuStrip1.SuspendLayout()
        Me.ToolStrip2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'menuStrip1
        '
        Me.menuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.fileToolStripMenuItem, Me.settingsToolStripMenuItem, Me.reportsToolStripMenuItem, Me.accessoriesToolStripMenuItem, Me.helpToolStripMenuItem})
        Me.menuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.menuStrip1.Name = "menuStrip1"
        Me.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.menuStrip1.Size = New System.Drawing.Size(1092, 24)
        Me.menuStrip1.TabIndex = 4
        Me.menuStrip1.Text = "menuStrip1"
        '
        'fileToolStripMenuItem
        '
        Me.fileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuNewTrans, Me.toolStripMenuItem1, Me.logOutToolStripMenuItem, Me.closeToolStripMenuItem})
        Me.fileToolStripMenuItem.Name = "fileToolStripMenuItem"
        Me.fileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.fileToolStripMenuItem.Text = "&File"
        '
        'mnuNewTrans
        '
        Me.mnuNewTrans.Name = "mnuNewTrans"
        Me.mnuNewTrans.Size = New System.Drawing.Size(170, 22)
        Me.mnuNewTrans.Text = "Manage Residents"
        '
        'toolStripMenuItem1
        '
        Me.toolStripMenuItem1.Name = "toolStripMenuItem1"
        Me.toolStripMenuItem1.Size = New System.Drawing.Size(167, 6)
        '
        'logOutToolStripMenuItem
        '
        Me.logOutToolStripMenuItem.Name = "logOutToolStripMenuItem"
        Me.logOutToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.logOutToolStripMenuItem.Text = "Log Out"
        '
        'closeToolStripMenuItem
        '
        Me.closeToolStripMenuItem.Name = "closeToolStripMenuItem"
        Me.closeToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.closeToolStripMenuItem.Text = "Close"
        '
        'settingsToolStripMenuItem
        '
        Me.settingsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.changePasswordToolStripMenuItem, Me.manageUsersToolStripMenuItem})
        Me.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem"
        Me.settingsToolStripMenuItem.Size = New System.Drawing.Size(61, 20)
        Me.settingsToolStripMenuItem.Text = "Settings"
        '
        'changePasswordToolStripMenuItem
        '
        Me.changePasswordToolStripMenuItem.Name = "changePasswordToolStripMenuItem"
        Me.changePasswordToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.changePasswordToolStripMenuItem.Text = "Change Password"
        '
        'manageUsersToolStripMenuItem
        '
        Me.manageUsersToolStripMenuItem.Name = "manageUsersToolStripMenuItem"
        Me.manageUsersToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.manageUsersToolStripMenuItem.Text = "Manage Users"
        '
        'reportsToolStripMenuItem
        '
        Me.reportsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.householdInformationReportToolStripMenuItem, Me.populationReportToolStripMenuItem, Me.religiousAffiliationReportToolStripMenuItem, Me.ageBracketReportToolStripMenuItem, Me.estimatedMonthlyIncomeReportToolStripMenuItem, Me.employmentToolStripMenuItem, Me.vehicleInformationReportToolStripMenuItem, Me.genderDistributionToolStripMenuItem, Me.civilStatusToolStripMenuItem})
        Me.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem"
        Me.reportsToolStripMenuItem.Size = New System.Drawing.Size(59, 20)
        Me.reportsToolStripMenuItem.Text = "Reports"
        '
        'householdInformationReportToolStripMenuItem
        '
        Me.householdInformationReportToolStripMenuItem.Name = "householdInformationReportToolStripMenuItem"
        Me.householdInformationReportToolStripMenuItem.Size = New System.Drawing.Size(236, 22)
        Me.householdInformationReportToolStripMenuItem.Text = "Household Information Report"
        '
        'populationReportToolStripMenuItem
        '
        Me.populationReportToolStripMenuItem.Name = "populationReportToolStripMenuItem"
        Me.populationReportToolStripMenuItem.Size = New System.Drawing.Size(236, 22)
        Me.populationReportToolStripMenuItem.Text = "Population Report"
        '
        'religiousAffiliationReportToolStripMenuItem
        '
        Me.religiousAffiliationReportToolStripMenuItem.Name = "religiousAffiliationReportToolStripMenuItem"
        Me.religiousAffiliationReportToolStripMenuItem.Size = New System.Drawing.Size(236, 22)
        Me.religiousAffiliationReportToolStripMenuItem.Text = "Religious Affiliation Report"
        '
        'ageBracketReportToolStripMenuItem
        '
        Me.ageBracketReportToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.toddlersToolStripMenuItem, Me.toolStripMenuItem3, Me.elementaryToolStripMenuItem, Me.highShoolToolStripMenuItem, Me.workingAgeToolStripMenuItem, Me.aboveSeniorCitizenToolStripMenuItem, Me.ageBracketSummaryReportToolStripMenuItem})
        Me.ageBracketReportToolStripMenuItem.Name = "ageBracketReportToolStripMenuItem"
        Me.ageBracketReportToolStripMenuItem.Size = New System.Drawing.Size(236, 22)
        Me.ageBracketReportToolStripMenuItem.Text = "Age Bracket Report"
        '
        'toddlersToolStripMenuItem
        '
        Me.toddlersToolStripMenuItem.Name = "toddlersToolStripMenuItem"
        Me.toddlersToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.toddlersToolStripMenuItem.Text = "0-2 Toddlers"
        '
        'toolStripMenuItem3
        '
        Me.toolStripMenuItem3.Name = "toolStripMenuItem3"
        Me.toolStripMenuItem3.Size = New System.Drawing.Size(229, 22)
        Me.toolStripMenuItem3.Text = "3-5 Pre-Schoolers"
        '
        'elementaryToolStripMenuItem
        '
        Me.elementaryToolStripMenuItem.Name = "elementaryToolStripMenuItem"
        Me.elementaryToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.elementaryToolStripMenuItem.Text = "6-12 Elementary"
        '
        'highShoolToolStripMenuItem
        '
        Me.highShoolToolStripMenuItem.Name = "highShoolToolStripMenuItem"
        Me.highShoolToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.highShoolToolStripMenuItem.Text = "13-17 High-Shool"
        '
        'workingAgeToolStripMenuItem
        '
        Me.workingAgeToolStripMenuItem.Name = "workingAgeToolStripMenuItem"
        Me.workingAgeToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.workingAgeToolStripMenuItem.Text = "18-64 Working Age"
        '
        'aboveSeniorCitizenToolStripMenuItem
        '
        Me.aboveSeniorCitizenToolStripMenuItem.Name = "aboveSeniorCitizenToolStripMenuItem"
        Me.aboveSeniorCitizenToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.aboveSeniorCitizenToolStripMenuItem.Text = "65 Above Senior Citizen"
        '
        'ageBracketSummaryReportToolStripMenuItem
        '
        Me.ageBracketSummaryReportToolStripMenuItem.Name = "ageBracketSummaryReportToolStripMenuItem"
        Me.ageBracketSummaryReportToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.ageBracketSummaryReportToolStripMenuItem.Text = "Age Bracket Summary Report"
        '
        'estimatedMonthlyIncomeReportToolStripMenuItem
        '
        Me.estimatedMonthlyIncomeReportToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lessThan5000ToolStripMenuItem, Me.toolStripMenuItem4, Me.toolStripMenuItem5, Me.toolStripMenuItem6, Me.toolStripMenuItem7, Me.toolStripMenuItem8, Me.over30000ToolStripMenuItem, Me.incomeSummaryReportToolStripMenuItem})
        Me.estimatedMonthlyIncomeReportToolStripMenuItem.Name = "estimatedMonthlyIncomeReportToolStripMenuItem"
        Me.estimatedMonthlyIncomeReportToolStripMenuItem.Size = New System.Drawing.Size(236, 22)
        Me.estimatedMonthlyIncomeReportToolStripMenuItem.Text = "Monthly Gross Income Report"
        '
        'lessThan5000ToolStripMenuItem
        '
        Me.lessThan5000ToolStripMenuItem.Name = "lessThan5000ToolStripMenuItem"
        Me.lessThan5000ToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.lessThan5000ToolStripMenuItem.Text = "Less Than 5,000"
        '
        'toolStripMenuItem4
        '
        Me.toolStripMenuItem4.Name = "toolStripMenuItem4"
        Me.toolStripMenuItem4.Size = New System.Drawing.Size(206, 22)
        Me.toolStripMenuItem4.Text = "5,000 - 10,000"
        '
        'toolStripMenuItem5
        '
        Me.toolStripMenuItem5.Name = "toolStripMenuItem5"
        Me.toolStripMenuItem5.Size = New System.Drawing.Size(206, 22)
        Me.toolStripMenuItem5.Text = "10,001 - 15,000"
        '
        'toolStripMenuItem6
        '
        Me.toolStripMenuItem6.Name = "toolStripMenuItem6"
        Me.toolStripMenuItem6.Size = New System.Drawing.Size(206, 22)
        Me.toolStripMenuItem6.Text = "15,001 - 20,000"
        '
        'toolStripMenuItem7
        '
        Me.toolStripMenuItem7.Name = "toolStripMenuItem7"
        Me.toolStripMenuItem7.Size = New System.Drawing.Size(206, 22)
        Me.toolStripMenuItem7.Text = "20,001 - 25,000"
        '
        'toolStripMenuItem8
        '
        Me.toolStripMenuItem8.Name = "toolStripMenuItem8"
        Me.toolStripMenuItem8.Size = New System.Drawing.Size(206, 22)
        Me.toolStripMenuItem8.Text = "25,001 - 30,000"
        '
        'over30000ToolStripMenuItem
        '
        Me.over30000ToolStripMenuItem.Name = "over30000ToolStripMenuItem"
        Me.over30000ToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.over30000ToolStripMenuItem.Text = "Over 30,000"
        '
        'incomeSummaryReportToolStripMenuItem
        '
        Me.incomeSummaryReportToolStripMenuItem.Name = "incomeSummaryReportToolStripMenuItem"
        Me.incomeSummaryReportToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.incomeSummaryReportToolStripMenuItem.Text = "Income Summary Report"
        '
        'employmentToolStripMenuItem
        '
        Me.employmentToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.employedToolStripMenuItem, Me.selfEmployedToolStripMenuItem, Me.unemployedToolStripMenuItem, Me.employmentSummaryReportToolStripMenuItem})
        Me.employmentToolStripMenuItem.Name = "employmentToolStripMenuItem"
        Me.employmentToolStripMenuItem.Size = New System.Drawing.Size(236, 22)
        Me.employmentToolStripMenuItem.Text = "Employment Report"
        '
        'employedToolStripMenuItem
        '
        Me.employedToolStripMenuItem.Name = "employedToolStripMenuItem"
        Me.employedToolStripMenuItem.Size = New System.Drawing.Size(234, 22)
        Me.employedToolStripMenuItem.Text = "Employed"
        '
        'selfEmployedToolStripMenuItem
        '
        Me.selfEmployedToolStripMenuItem.Name = "selfEmployedToolStripMenuItem"
        Me.selfEmployedToolStripMenuItem.Size = New System.Drawing.Size(234, 22)
        Me.selfEmployedToolStripMenuItem.Text = "Self-Employed"
        '
        'unemployedToolStripMenuItem
        '
        Me.unemployedToolStripMenuItem.Name = "unemployedToolStripMenuItem"
        Me.unemployedToolStripMenuItem.Size = New System.Drawing.Size(234, 22)
        Me.unemployedToolStripMenuItem.Text = "Unemployed"
        '
        'employmentSummaryReportToolStripMenuItem
        '
        Me.employmentSummaryReportToolStripMenuItem.Name = "employmentSummaryReportToolStripMenuItem"
        Me.employmentSummaryReportToolStripMenuItem.Size = New System.Drawing.Size(234, 22)
        Me.employmentSummaryReportToolStripMenuItem.Text = "Employment Summary Report"
        '
        'vehicleInformationReportToolStripMenuItem
        '
        Me.vehicleInformationReportToolStripMenuItem.Name = "vehicleInformationReportToolStripMenuItem"
        Me.vehicleInformationReportToolStripMenuItem.Size = New System.Drawing.Size(236, 22)
        Me.vehicleInformationReportToolStripMenuItem.Text = "Vehicle Information Report"
        '
        'genderDistributionToolStripMenuItem
        '
        Me.genderDistributionToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.maleToolStripMenuItem, Me.femaleToolStripMenuItem})
        Me.genderDistributionToolStripMenuItem.Name = "genderDistributionToolStripMenuItem"
        Me.genderDistributionToolStripMenuItem.Size = New System.Drawing.Size(236, 22)
        Me.genderDistributionToolStripMenuItem.Text = "Gender Distribution"
        '
        'maleToolStripMenuItem
        '
        Me.maleToolStripMenuItem.Name = "maleToolStripMenuItem"
        Me.maleToolStripMenuItem.Size = New System.Drawing.Size(112, 22)
        Me.maleToolStripMenuItem.Text = "Male"
        '
        'femaleToolStripMenuItem
        '
        Me.femaleToolStripMenuItem.Name = "femaleToolStripMenuItem"
        Me.femaleToolStripMenuItem.Size = New System.Drawing.Size(112, 22)
        Me.femaleToolStripMenuItem.Text = "Female"
        '
        'civilStatusToolStripMenuItem
        '
        Me.civilStatusToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.singleToolStripMenuItem, Me.marriedToolStripMenuItem, Me.widowWidowerToolStripMenuItem})
        Me.civilStatusToolStripMenuItem.Name = "civilStatusToolStripMenuItem"
        Me.civilStatusToolStripMenuItem.Size = New System.Drawing.Size(236, 22)
        Me.civilStatusToolStripMenuItem.Text = "Civil Status"
        '
        'singleToolStripMenuItem
        '
        Me.singleToolStripMenuItem.Name = "singleToolStripMenuItem"
        Me.singleToolStripMenuItem.Size = New System.Drawing.Size(163, 22)
        Me.singleToolStripMenuItem.Text = "Single"
        '
        'marriedToolStripMenuItem
        '
        Me.marriedToolStripMenuItem.Name = "marriedToolStripMenuItem"
        Me.marriedToolStripMenuItem.Size = New System.Drawing.Size(163, 22)
        Me.marriedToolStripMenuItem.Text = "Married"
        '
        'widowWidowerToolStripMenuItem
        '
        Me.widowWidowerToolStripMenuItem.Name = "widowWidowerToolStripMenuItem"
        Me.widowWidowerToolStripMenuItem.Size = New System.Drawing.Size(163, 22)
        Me.widowWidowerToolStripMenuItem.Text = "Widow/Widower"
        '
        'accessoriesToolStripMenuItem
        '
        Me.accessoriesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.calculatorToolStripMenuItem, Me.internetBrowserToolStripMenuItem, Me.taskManagerToolStripMenuItem, Me.servicesToolStripMenuItem, Me.commandLineToolStripMenuItem, Me.systemInformationToolStripMenuItem})
        Me.accessoriesToolStripMenuItem.Name = "accessoriesToolStripMenuItem"
        Me.accessoriesToolStripMenuItem.Size = New System.Drawing.Size(80, 20)
        Me.accessoriesToolStripMenuItem.Text = "Accessories"
        Me.accessoriesToolStripMenuItem.Visible = False
        '
        'calculatorToolStripMenuItem
        '
        Me.calculatorToolStripMenuItem.Name = "calculatorToolStripMenuItem"
        Me.calculatorToolStripMenuItem.Size = New System.Drawing.Size(178, 22)
        Me.calculatorToolStripMenuItem.Text = "Calculator"
        '
        'internetBrowserToolStripMenuItem
        '
        Me.internetBrowserToolStripMenuItem.Name = "internetBrowserToolStripMenuItem"
        Me.internetBrowserToolStripMenuItem.Size = New System.Drawing.Size(178, 22)
        Me.internetBrowserToolStripMenuItem.Text = "Internet Browser"
        '
        'taskManagerToolStripMenuItem
        '
        Me.taskManagerToolStripMenuItem.Name = "taskManagerToolStripMenuItem"
        Me.taskManagerToolStripMenuItem.Size = New System.Drawing.Size(178, 22)
        Me.taskManagerToolStripMenuItem.Text = "Task Manager"
        '
        'servicesToolStripMenuItem
        '
        Me.servicesToolStripMenuItem.Name = "servicesToolStripMenuItem"
        Me.servicesToolStripMenuItem.Size = New System.Drawing.Size(178, 22)
        Me.servicesToolStripMenuItem.Text = "Services"
        '
        'commandLineToolStripMenuItem
        '
        Me.commandLineToolStripMenuItem.Name = "commandLineToolStripMenuItem"
        Me.commandLineToolStripMenuItem.Size = New System.Drawing.Size(178, 22)
        Me.commandLineToolStripMenuItem.Text = "Command Line"
        '
        'systemInformationToolStripMenuItem
        '
        Me.systemInformationToolStripMenuItem.Name = "systemInformationToolStripMenuItem"
        Me.systemInformationToolStripMenuItem.Size = New System.Drawing.Size(178, 22)
        Me.systemInformationToolStripMenuItem.Text = "System Information"
        '
        'helpToolStripMenuItem
        '
        Me.helpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.aboutToolStripMenuItem})
        Me.helpToolStripMenuItem.Name = "helpToolStripMenuItem"
        Me.helpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.helpToolStripMenuItem.Text = "Help"
        '
        'aboutToolStripMenuItem
        '
        Me.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem"
        Me.aboutToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.aboutToolStripMenuItem.Text = "About"
        '
        'ToolStrip2
        '
        Me.ToolStrip2.GripMargin = New System.Windows.Forms.Padding(1)
        Me.ToolStrip2.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip2.ImageScalingSize = New System.Drawing.Size(30, 30)
        Me.ToolStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripSeparator2, Me.tlshousehold, Me.tlsPurok, Me.tlsofficials, Me.ToolStripSeparator3, Me.tlsbrgycl, Me.ToolStripButton1, Me.tlsBroadcast, Me.ToolStripSeparator1, Me.ToolStripSeparator4, Me.ToolStripButton2, Me.tlsDTR, Me.ToolStripSeparator5, Me.tlsreports, Me.TLlogin, Me.TSUser})
        Me.ToolStrip2.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip2.Name = "ToolStrip2"
        Me.ToolStrip2.Size = New System.Drawing.Size(1092, 52)
        Me.ToolStrip2.TabIndex = 5
        Me.ToolStrip2.Text = "Reports"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 52)
        '
        'tlshousehold
        '
        Me.tlshousehold.Image = CType(resources.GetObject("tlshousehold.Image"), System.Drawing.Image)
        Me.tlshousehold.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tlshousehold.Name = "tlshousehold"
        Me.tlshousehold.Size = New System.Drawing.Size(69, 49)
        Me.tlshousehold.Text = "Household"
        Me.tlshousehold.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.tlshousehold.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'tlsPurok
        '
        Me.tlsPurok.Image = CType(resources.GetObject("tlsPurok.Image"), System.Drawing.Image)
        Me.tlsPurok.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tlsPurok.Name = "tlsPurok"
        Me.tlsPurok.Size = New System.Drawing.Size(42, 49)
        Me.tlsPurok.Text = "Purok"
        Me.tlsPurok.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.tlsPurok.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'tlsofficials
        '
        Me.tlsofficials.Image = CType(resources.GetObject("tlsofficials.Image"), System.Drawing.Image)
        Me.tlsofficials.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tlsofficials.Name = "tlsofficials"
        Me.tlsofficials.Size = New System.Drawing.Size(54, 49)
        Me.tlsofficials.Text = "Officials"
        Me.tlsofficials.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.tlsofficials.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 52)
        '
        'tlsbrgycl
        '
        Me.tlsbrgycl.Image = Global.BRGYINFOSYS.My.Resources.Resources.category
        Me.tlsbrgycl.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tlsbrgycl.Name = "tlsbrgycl"
        Me.tlsbrgycl.Size = New System.Drawing.Size(93, 49)
        Me.tlsbrgycl.Text = "Brgy. Clearance"
        Me.tlsbrgycl.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.tlsbrgycl.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.Image = Global.BRGYINFOSYS.My.Resources.Resources.category
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(88, 49)
        Me.ToolStripButton1.Text = "Bus. Clearance"
        Me.ToolStripButton1.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ToolStripButton1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'tlsBroadcast
        '
        Me.tlsBroadcast.Image = Global.BRGYINFOSYS.My.Resources.Resources.contacts
        Me.tlsBroadcast.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tlsBroadcast.Name = "tlsBroadcast"
        Me.tlsBroadcast.Size = New System.Drawing.Size(34, 49)
        Me.tlsBroadcast.Text = "CTC"
        Me.tlsBroadcast.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.tlsBroadcast.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 52)
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(6, 52)
        '
        'ToolStripButton2
        '
        Me.ToolStripButton2.Image = CType(resources.GetObject("ToolStripButton2.Image"), System.Drawing.Image)
        Me.ToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton2.Name = "ToolStripButton2"
        Me.ToolStripButton2.Size = New System.Drawing.Size(63, 49)
        Me.ToolStripButton2.Text = "Complain"
        Me.ToolStripButton2.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ToolStripButton2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'tlsDTR
        '
        Me.tlsDTR.Image = CType(resources.GetObject("tlsDTR.Image"), System.Drawing.Image)
        Me.tlsDTR.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tlsDTR.Name = "tlsDTR"
        Me.tlsDTR.Size = New System.Drawing.Size(46, 49)
        Me.tlsDTR.Text = "Blotter"
        Me.tlsDTR.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.tlsDTR.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(6, 52)
        '
        'tlsreports
        '
        Me.tlsreports.Image = Global.BRGYINFOSYS.My.Resources.Resources.category
        Me.tlsreports.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tlsreports.Name = "tlsreports"
        Me.tlsreports.Size = New System.Drawing.Size(51, 49)
        Me.tlsreports.Text = "Reports"
        Me.tlsreports.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.tlsreports.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'TLlogin
        '
        Me.TLlogin.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.TLlogin.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TLlogin.Name = "TLlogin"
        Me.TLlogin.Size = New System.Drawing.Size(41, 49)
        Me.TLlogin.Text = "Login"
        Me.TLlogin.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.TLlogin.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'TSUser
        '
        Me.TSUser.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.TSUser.Name = "TSUser"
        Me.TSUser.Size = New System.Drawing.Size(58, 49)
        Me.TSUser.Text = "Hi, Guest!"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.Highlight
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 76)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1092, 60)
        Me.Panel1.TabIndex = 22
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label1.Location = New System.Drawing.Point(17, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(764, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Barangay  Uno,  Katipunan,  Zamboanga  del  Norte Information System"
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1092, 583)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.ToolStrip2)
        Me.Controls.Add(Me.menuStrip1)
        Me.Name = "Main"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.menuStrip1.ResumeLayout(False)
        Me.menuStrip1.PerformLayout()
        Me.ToolStrip2.ResumeLayout(False)
        Me.ToolStrip2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents menuStrip1 As System.Windows.Forms.MenuStrip
    Private WithEvents fileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents mnuNewTrans As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents toolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
    Private WithEvents logOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents closeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents settingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents changePasswordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents manageUsersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents reportsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents householdInformationReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents populationReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents religiousAffiliationReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents ageBracketReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents toddlersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents toolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents elementaryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents highShoolToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents workingAgeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents aboveSeniorCitizenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents ageBracketSummaryReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents estimatedMonthlyIncomeReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents lessThan5000ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents toolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents toolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents toolStripMenuItem6 As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents toolStripMenuItem7 As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents toolStripMenuItem8 As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents over30000ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents incomeSummaryReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents employmentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents employedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents selfEmployedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents unemployedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents employmentSummaryReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents vehicleInformationReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents genderDistributionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents maleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents femaleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents civilStatusToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents singleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents marriedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents widowWidowerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents accessoriesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents calculatorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents internetBrowserToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents taskManagerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents servicesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents commandLineToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents systemInformationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents helpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents aboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStrip2 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tlshousehold As System.Windows.Forms.ToolStripButton
    Friend WithEvents tlsPurok As System.Windows.Forms.ToolStripButton
    Friend WithEvents tlsofficials As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tlsBroadcast As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tlsbrgycl As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tlsDTR As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tlsreports As System.Windows.Forms.ToolStripButton
    Friend WithEvents TLlogin As System.Windows.Forms.ToolStripButton
    Friend WithEvents TSUser As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripButton1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ToolStripButton2 As System.Windows.Forms.ToolStripButton

End Class
