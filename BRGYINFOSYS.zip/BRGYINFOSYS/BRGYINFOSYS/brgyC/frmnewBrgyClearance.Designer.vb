﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmnewBrgyClearance
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label15 = New System.Windows.Forms.Label
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Lblsupliertitle = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.TXTADDRESS = New System.Windows.Forms.TextBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.txtlname = New System.Windows.Forms.TextBox
        Me.btnsave = New System.Windows.Forms.Button
        Me.btnsearch = New System.Windows.Forms.Button
        Me.TXTGENDER = New System.Windows.Forms.TextBox
        Me.TXTAGE = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.TXTCIVIL = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.TXTPURPOSE = New System.Windows.Forms.TextBox
        Me.TXTOR = New System.Windows.Forms.TextBox
        Me.TXTDATEGIVEN = New System.Windows.Forms.DateTimePicker
        Me.Label3 = New System.Windows.Forms.Label
        Me.TXTENCODER = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtCaptain = New System.Windows.Forms.TextBox
        Me.brgycaptain = New System.Windows.Forms.Label
        Me.txtresno = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtresIssAt = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtissuedat = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.dtRissued = New System.Windows.Forms.DateTimePicker
        Me.dtIssued = New System.Windows.Forms.DateTimePicker
        Me.Panel2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(51, 37)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(69, 16)
        Me.Label15.TabIndex = 28
        Me.Label15.Text = "Fullname :"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.Highlight
        Me.Panel2.Controls.Add(Me.Lblsupliertitle)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(484, 60)
        Me.Panel2.TabIndex = 35
        '
        'Lblsupliertitle
        '
        Me.Lblsupliertitle.AutoSize = True
        Me.Lblsupliertitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblsupliertitle.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Lblsupliertitle.Location = New System.Drawing.Point(17, 20)
        Me.Lblsupliertitle.Name = "Lblsupliertitle"
        Me.Lblsupliertitle.Size = New System.Drawing.Size(281, 25)
        Me.Lblsupliertitle.TabIndex = 0
        Me.Lblsupliertitle.Text = "Add New Brgy. Clearance"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(247, 27)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(85, 16)
        Me.Label13.TabIndex = 25
        Me.Label13.Text = "OR Number :"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(41, 120)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(79, 16)
        Me.Label12.TabIndex = 23
        Me.Label12.Text = "Civil Status :"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(61, 67)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(59, 16)
        Me.Label11.TabIndex = 21
        Me.Label11.Text = "Gender :"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(54, 151)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(65, 16)
        Me.Label10.TabIndex = 19
        Me.Label10.Text = "Address ;"
        '
        'TXTADDRESS
        '
        Me.TXTADDRESS.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TXTADDRESS.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TXTADDRESS.BackColor = System.Drawing.SystemColors.HighlightText
        Me.TXTADDRESS.Enabled = False
        Me.TXTADDRESS.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXTADDRESS.Location = New System.Drawing.Point(126, 145)
        Me.TXTADDRESS.Name = "TXTADDRESS"
        Me.TXTADDRESS.Size = New System.Drawing.Size(318, 22)
        Me.TXTADDRESS.TabIndex = 18
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtCaptain)
        Me.GroupBox1.Controls.Add(Me.brgycaptain)
        Me.GroupBox1.Controls.Add(Me.TXTENCODER)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.TXTDATEGIVEN)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.TXTPURPOSE)
        Me.GroupBox1.Controls.Add(Me.TXTCIVIL)
        Me.GroupBox1.Controls.Add(Me.TXTAGE)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.TXTGENDER)
        Me.GroupBox1.Controls.Add(Me.btnsearch)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.TXTADDRESS)
        Me.GroupBox1.Controls.Add(Me.txtlname)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 66)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(462, 288)
        Me.GroupBox1.TabIndex = 34
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Details"
        '
        'txtlname
        '
        Me.txtlname.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtlname.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtlname.BackColor = System.Drawing.SystemColors.HighlightText
        Me.txtlname.Enabled = False
        Me.txtlname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtlname.Location = New System.Drawing.Point(126, 31)
        Me.txtlname.Name = "txtlname"
        Me.txtlname.Size = New System.Drawing.Size(197, 22)
        Me.txtlname.TabIndex = 1
        '
        'btnsave
        '
        Me.btnsave.Location = New System.Drawing.Point(139, 478)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(159, 39)
        Me.btnsave.TabIndex = 36
        Me.btnsave.Text = "Save"
        Me.btnsave.UseVisualStyleBackColor = True
        '
        'btnsearch
        '
        Me.btnsearch.Location = New System.Drawing.Point(329, 30)
        Me.btnsearch.Name = "btnsearch"
        Me.btnsearch.Size = New System.Drawing.Size(52, 23)
        Me.btnsearch.TabIndex = 1
        Me.btnsearch.Text = "Search"
        Me.btnsearch.UseVisualStyleBackColor = True
        '
        'TXTGENDER
        '
        Me.TXTGENDER.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TXTGENDER.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TXTGENDER.BackColor = System.Drawing.SystemColors.HighlightText
        Me.TXTGENDER.Enabled = False
        Me.TXTGENDER.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXTGENDER.Location = New System.Drawing.Point(126, 61)
        Me.TXTGENDER.Name = "TXTGENDER"
        Me.TXTGENDER.Size = New System.Drawing.Size(197, 22)
        Me.TXTGENDER.TabIndex = 48
        '
        'TXTAGE
        '
        Me.TXTAGE.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TXTAGE.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TXTAGE.BackColor = System.Drawing.SystemColors.HighlightText
        Me.TXTAGE.Enabled = False
        Me.TXTAGE.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXTAGE.Location = New System.Drawing.Point(126, 89)
        Me.TXTAGE.Name = "TXTAGE"
        Me.TXTAGE.Size = New System.Drawing.Size(42, 22)
        Me.TXTAGE.TabIndex = 50
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(81, 95)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 16)
        Me.Label1.TabIndex = 49
        Me.Label1.Text = "Age :"
        '
        'TXTCIVIL
        '
        Me.TXTCIVIL.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TXTCIVIL.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TXTCIVIL.BackColor = System.Drawing.SystemColors.HighlightText
        Me.TXTCIVIL.Enabled = False
        Me.TXTCIVIL.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXTCIVIL.Location = New System.Drawing.Point(126, 117)
        Me.TXTCIVIL.Name = "TXTCIVIL"
        Me.TXTCIVIL.Size = New System.Drawing.Size(197, 22)
        Me.TXTCIVIL.TabIndex = 51
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(54, 179)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(62, 16)
        Me.Label2.TabIndex = 53
        Me.Label2.Text = "Purpose "
        '
        'TXTPURPOSE
        '
        Me.TXTPURPOSE.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TXTPURPOSE.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TXTPURPOSE.BackColor = System.Drawing.SystemColors.HighlightText
        Me.TXTPURPOSE.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXTPURPOSE.Location = New System.Drawing.Point(126, 173)
        Me.TXTPURPOSE.Name = "TXTPURPOSE"
        Me.TXTPURPOSE.Size = New System.Drawing.Size(197, 22)
        Me.TXTPURPOSE.TabIndex = 2
        '
        'TXTOR
        '
        Me.TXTOR.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TXTOR.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TXTOR.BackColor = System.Drawing.SystemColors.HighlightText
        Me.TXTOR.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXTOR.Location = New System.Drawing.Point(342, 21)
        Me.TXTOR.Name = "TXTOR"
        Me.TXTOR.Size = New System.Drawing.Size(102, 22)
        Me.TXTOR.TabIndex = 65
        '
        'TXTDATEGIVEN
        '
        Me.TXTDATEGIVEN.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.TXTDATEGIVEN.Location = New System.Drawing.Point(126, 201)
        Me.TXTDATEGIVEN.Name = "TXTDATEGIVEN"
        Me.TXTDATEGIVEN.Size = New System.Drawing.Size(197, 20)
        Me.TXTDATEGIVEN.TabIndex = 55
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(39, 205)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(81, 16)
        Me.Label3.TabIndex = 56
        Me.Label3.Text = "Date Given :"
        '
        'TXTENCODER
        '
        Me.TXTENCODER.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TXTENCODER.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TXTENCODER.BackColor = System.Drawing.SystemColors.HighlightText
        Me.TXTENCODER.Enabled = False
        Me.TXTENCODER.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXTENCODER.Location = New System.Drawing.Point(126, 227)
        Me.TXTENCODER.Name = "TXTENCODER"
        Me.TXTENCODER.Size = New System.Drawing.Size(197, 22)
        Me.TXTENCODER.TabIndex = 58
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(48, 233)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(68, 16)
        Me.Label4.TabIndex = 57
        Me.Label4.Text = "Given By :"
        '
        'txtCaptain
        '
        Me.txtCaptain.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtCaptain.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtCaptain.BackColor = System.Drawing.SystemColors.HighlightText
        Me.txtCaptain.Enabled = False
        Me.txtCaptain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCaptain.Location = New System.Drawing.Point(126, 255)
        Me.txtCaptain.Name = "txtCaptain"
        Me.txtCaptain.Size = New System.Drawing.Size(197, 22)
        Me.txtCaptain.TabIndex = 60
        '
        'brgycaptain
        '
        Me.brgycaptain.AutoSize = True
        Me.brgycaptain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.brgycaptain.Location = New System.Drawing.Point(21, 261)
        Me.brgycaptain.Name = "brgycaptain"
        Me.brgycaptain.Size = New System.Drawing.Size(94, 16)
        Me.brgycaptain.TabIndex = 59
        Me.brgycaptain.Text = "Brgy. Captain :"
        '
        'txtresno
        '
        Me.txtresno.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtresno.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtresno.BackColor = System.Drawing.SystemColors.HighlightText
        Me.txtresno.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtresno.Location = New System.Drawing.Point(108, 21)
        Me.txtresno.Name = "txtresno"
        Me.txtresno.Size = New System.Drawing.Size(115, 22)
        Me.txtresno.TabIndex = 62
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(3, 27)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(96, 16)
        Me.Label5.TabIndex = 61
        Me.Label5.Text = "Res. Cert. No. :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(23, 55)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(74, 16)
        Me.Label6.TabIndex = 63
        Me.Label6.Text = "Issued On :"
        '
        'txtresIssAt
        '
        Me.txtresIssAt.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtresIssAt.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtresIssAt.BackColor = System.Drawing.SystemColors.HighlightText
        Me.txtresIssAt.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtresIssAt.Location = New System.Drawing.Point(108, 77)
        Me.txtresIssAt.Name = "txtresIssAt"
        Me.txtresIssAt.Size = New System.Drawing.Size(115, 22)
        Me.txtresIssAt.TabIndex = 64
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(28, 83)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(69, 16)
        Me.Label7.TabIndex = 65
        Me.Label7.Text = "Issued At :"
        '
        'txtissuedat
        '
        Me.txtissuedat.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtissuedat.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtissuedat.BackColor = System.Drawing.SystemColors.HighlightText
        Me.txtissuedat.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtissuedat.Location = New System.Drawing.Point(343, 77)
        Me.txtissuedat.Name = "txtissuedat"
        Me.txtissuedat.Size = New System.Drawing.Size(101, 22)
        Me.txtissuedat.TabIndex = 67
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(263, 83)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(69, 16)
        Me.Label8.TabIndex = 71
        Me.Label8.Text = "Issued At :"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(258, 55)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(74, 16)
        Me.Label9.TabIndex = 69
        Me.Label9.Text = "Issued On :"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.dtIssued)
        Me.GroupBox2.Controls.Add(Me.dtRissued)
        Me.GroupBox2.Controls.Add(Me.txtissuedat)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.TXTOR)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.txtresno)
        Me.GroupBox2.Controls.Add(Me.txtresIssAt)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 360)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(462, 112)
        Me.GroupBox2.TabIndex = 36
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Other details"
        '
        'dtRissued
        '
        Me.dtRissued.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtRissued.Location = New System.Drawing.Point(108, 51)
        Me.dtRissued.Name = "dtRissued"
        Me.dtRissued.Size = New System.Drawing.Size(115, 20)
        Me.dtRissued.TabIndex = 61
        '
        'dtIssued
        '
        Me.dtIssued.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtIssued.Location = New System.Drawing.Point(342, 51)
        Me.dtIssued.Name = "dtIssued"
        Me.dtIssued.Size = New System.Drawing.Size(102, 20)
        Me.dtIssued.TabIndex = 72
        '
        'frmnewBrgyClearance
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(484, 523)
        Me.Controls.Add(Me.btnsave)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "frmnewBrgyClearance"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Lblsupliertitle As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TXTADDRESS As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtlname As System.Windows.Forms.TextBox
    Friend WithEvents btnsave As System.Windows.Forms.Button
    Friend WithEvents btnsearch As System.Windows.Forms.Button
    Friend WithEvents TXTAGE As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TXTGENDER As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TXTPURPOSE As System.Windows.Forms.TextBox
    Friend WithEvents TXTCIVIL As System.Windows.Forms.TextBox
    Friend WithEvents TXTOR As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TXTDATEGIVEN As System.Windows.Forms.DateTimePicker
    Friend WithEvents TXTENCODER As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtresIssAt As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtresno As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtCaptain As System.Windows.Forms.TextBox
    Friend WithEvents brgycaptain As System.Windows.Forms.Label
    Friend WithEvents txtissuedat As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents dtIssued As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtRissued As System.Windows.Forms.DateTimePicker
End Class
