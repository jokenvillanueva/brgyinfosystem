﻿Module brgycontroller

    Public Function SaveBrgyClearance(ByVal saving As String, ByVal sqlstring As String) As Boolean

        Try


            If saving = "SaveOnly" Then
                sql = sqlstring
            ElseIf saving = "UpdateOnly" Then
                sql = sqlstring

            End If
            con.Open()
            cmd.Connection = con
            cmd.CommandText = sql
            With frmnewBrgyClearance
                If saving = "SaveOnly" Then
                    '   "INSERT INTO `tblbrgyclearance` ( `RESID`, `FULLNAME`, `PURPOSE`, `DATEGIVEN`, " & _
                    '"`ORNo`, `ISSUEDON`, `ISSUEDAT`, `RESCERT`, `RESSISSUEDON`, `RESSISSUEDAT`, `BRGYCAPTAIN`) " & _
                    '                                " VALUES ( @RESID, @FULLNAME, @PURPOSE, @DATEGIVEN, " & _
                    '" @ORNo, @ISSUEDON, @ISSUEDAT, @RESCERT, @RESSISSUEDON, @RESSISSUEDAT, @BRGYCAPTAIN);"

                    cmd.Parameters.AddWithValue("@RESID", .Text)
                    cmd.Parameters.AddWithValue("@FULLNAME", .txtlname.Text)
                    cmd.Parameters.AddWithValue("@PURPOSE", .TXTPURPOSE.Text)
                    cmd.Parameters.AddWithValue("@DATEGIVEN", Format(.TXTDATEGIVEN.Value, "yyyy-MM-dd"))
                    cmd.Parameters.AddWithValue("@ORNo", .TXTOR.Text)
                    cmd.Parameters.AddWithValue("@ISSUEDON", Format(.dtIssued.Value, "yyyy-MM-dd"))
                    cmd.Parameters.AddWithValue("@ISSUEDAT", .txtissuedat.Text)
                    cmd.Parameters.AddWithValue("@RESCERT", .txtresno.Text)
                    cmd.Parameters.AddWithValue("@RESSISSUEDON", Format(.dtRissued.Value, "yyyy-MM-dd"))
                    cmd.Parameters.AddWithValue("@RESSISSUEDAT", .txtresIssAt.Text)
                    cmd.Parameters.AddWithValue("@BRGYCAPTAIN", .txtCaptain.Text)
                    cmd.Parameters.AddWithValue("@ISSUEDBY", .TXTENCODER.Text)

                ElseIf saving = "UpdateOnly" Then
                    ' cmd.Parameters.AddWithValue("@RESID", .Text)
                    cmd.Parameters.AddWithValue("@FULLNAME", .txtlname.Text)
                    cmd.Parameters.AddWithValue("@PURPOSE", .TXTPURPOSE.Text)
                    cmd.Parameters.AddWithValue("@DATEGIVEN", Format(.TXTDATEGIVEN.Value, "yyyy-MM-dd"))
                    cmd.Parameters.AddWithValue("@ORNo", .TXTOR.Text)
                    cmd.Parameters.AddWithValue("@ISSUEDON", Format(.dtIssued.Value, "yyyy-MM-dd"))
                    cmd.Parameters.AddWithValue("@ISSUEDAT", .txtissuedat.Text)
                    cmd.Parameters.AddWithValue("@RESCERT", .txtresno.Text)
                    cmd.Parameters.AddWithValue("@RESSISSUEDON", Format(.dtRissued.Value, "yyyy-MM-dd"))
                    cmd.Parameters.AddWithValue("@RESSISSUEDAT", .txtresIssAt.Text)
                    cmd.Parameters.AddWithValue("@BRGYCAPTAIN", .txtCaptain.Text)
                    cmd.Parameters.AddWithValue("@ISSUEDBY", .TXTENCODER.Text)
                    cmd.Parameters.AddWithValue("@ID", .Text)

                End If

            End With
            result = cmd.ExecuteNonQuery
            If result > 0 Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            cmd.Parameters.Clear()
            cmd.Dispose()
            con.Close()

        End Try
    End Function

    Public Sub LoadBrgyClearance(ByVal obj As Object, ByVal param As String)
        Try
            con.Open()
            dReader = cmd.ExecuteReader()
            '  obj.Rows.Clear()
            Select Case param
                Case "brgy"
                    obj.Rows.Clear()
                    Do While dReader.Read = True

                        obj.Rows.Add(dReader(0), dReader(1), dReader(2), DateDiff(DateInterval.Year, dReader(3), Now.Date), dReader(4), dReader(5), dReader(6), dReader(7), dReader(8), dReader(9))

                    Loop
            End Select
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            da.Dispose()
            con.Close()
        End Try
    End Sub
    Public Sub loadsinglECaptain(ByVal param As String, ByVal par As String)
        Try
            con.Open()
            dReader = cmd.ExecuteReader()
            '  obj.Rows.Clear()
            Select Case param
                Case "captain"
                    Do While dReader.Read = True
                        If par = "BRGY" Then
                            With frmnewBrgyClearance
                                .txtCaptain.Text = dReader("EMPNAME")
                            End With
                        ElseIf par = "BUS" Then
                            With frmnewbusiness
                                .txtCaptain.Text = dReader("EMPNAME")
                            End With
                        End If
                      
                    Loop
            End Select
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            da.Dispose()
            con.Close()
        End Try
    End Sub
    Public Sub loadsingleBrgy(ByVal param As String)
        Try
            con.Open()
            dReader = cmd.ExecuteReader()
            '  obj.Rows.Clear()
            Select Case param
                Case "brgy"
                    Do While dReader.Read = True
                        With frmnewBrgyClearance


                            .Text = dReader("ID")
                            .txtlname.Text = dReader("FULLNAME")
                            .TXTPURPOSE.Text = dReader("PURPOSE")
                            .TXTGENDER.Text = SEX
                            .TXTAGE.Text = DateDiff(DateInterval.Year, dReader("DOB"), Now.Date)
                            .TXTCIVIL.Text = dReader("CIVIL")
                            .TXTADDRESS.Text = dReader("ADDRESS")
                            .TXTDATEGIVEN.Value = Format(dReader("DATEGIVEN"), "yyyy-MM-dd")
                            .TXTOR.Text = dReader("ORNo")
                            .TXTENCODER.Text = dReader("ISSUEDBY")
                            .dtIssued.Value = Format(dReader("ISSUEDON"), "yyyy-MM-dd")
                            .txtissuedat.Text = dReader("ISSUEDAT")
                            .txtresno.Text = dReader("RESCERT")
                            .txtresIssAt.Text = dReader("RESSISSUEDAT")
                            .dtRissued.Value = Format(dReader("RESSISSUEDON"), "yyyy-MM-dd")
                            .txtCaptain.Text = dReader("BRGYCAPTAIN")


                        End With
                    Loop

            End Select
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            da.Dispose()
            con.Close()
        End Try
    End Sub

End Module
