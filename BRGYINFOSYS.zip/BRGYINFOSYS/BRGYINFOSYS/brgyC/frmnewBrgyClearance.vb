﻿Public Class frmnewBrgyClearance

    Private Sub Label13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label13.Click

    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        CLEARANCE = "BRGY"
        frmhousehold.Show()


    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        If btnsave.Text = "Save" Then
            sql = "INSERT INTO `tblbrgyclearance` ( `RESID`, `FULLNAME`, `PURPOSE`, `DATEGIVEN`, " & _
                "`ORNo`, `ISSUEDON`, `ISSUEDAT`, `RESCERT`, `RESSISSUEDON`, `RESSISSUEDAT`, `BRGYCAPTAIN`,ISSUEDBY) " & _
                                                " VALUES ( @RESID, @FULLNAME, @PURPOSE, @DATEGIVEN, " & _
                " @ORNo, @ISSUEDON, @ISSUEDAT, @RESCERT, @RESSISSUEDON, @RESSISSUEDAT, @BRGYCAPTAIN, @ISSUEDBY);"

            issucess = SaveBrgyClearance("SaveOnly", sql)

            If issucess = True Then
                MsgBox("New Brgy. Clearance has been added!")
            Else
                MsgBox("No Brgy. Clearance has been added!")
            End If

            jokenfindthis("Select * from tblresidence")
            LoadHousehold(frmhousehold.DataGridView1, "Household")
            Me.Close()
        Else
            sql = "UPDATE `tblbrgyclearance` SET `FULLNAME` = @FULLNAME, " & _
            " `PURPOSE` = @PURPOSE, `DATEGIVEN` = @DATEGIVEN, `ORNo` = @ORNo," & _
            " `ISSUEDON` = @ISSUEDON, `ISSUEDAT` = @ISSUEDAT, `RESCERT` = @RESCERT, " & _
            " `RESSISSUEDON` = @RESSISSUEDON, `RESSISSUEDAT` = @RESSISSUEDAT, `BRGYCAPTAIN` = @BRGYCAPTAIN," & _
            " `ISSUEDBY` = @ISSUEDBY WHERE `tblbrgyclearance`.`ID` = @ID;"

            issucess = SaveBrgyClearance("UpdateOnly", sql)

            If issucess = True Then
                MsgBox("Brgy. Clearance has been updated!")
            Else
                MsgBox("No Brgy. Clearance has been updated!")
            End If

            jokenfindthis("SELECT `ID`, `FULLNAME`,`SEX`,`DOB`,`CIVIL`, CONCAT(`NO`,`STREET`,`PRK`)AS ADDRESS, `PURPOSE`, `ORNo`,`DATEGIVEN`,BRGYCAPTAIN FROM `tblbrgyclearance` c, tblresidence r WHERE c.`RESID` = r.RESIDENCEID")
            LoadBrgyClearance(frmbrgyClearance.DataGridView1, "brgy")
            Me.Close()

        End If
    End Sub

    Private Sub frmnewBrgyClearance_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


    End Sub
End Class