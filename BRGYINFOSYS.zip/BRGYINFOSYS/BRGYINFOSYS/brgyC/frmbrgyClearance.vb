﻿Public Class frmbrgyClearance

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        jokenfindthis("SELECT * FROM `tblemployee` WHERE `EMPPOSITION` ='CAPTAIN' AND `ACCSTATUS` ='YES'")
        loadsinglECaptain("captain", "BRGY")
        frmnewBrgyClearance.TXTENCODER.Text = fullname
        frmnewBrgyClearance.Show()

    End Sub

    Private Sub txtsearch_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtsearch.TextChanged
        jokenfindthis("SELECT `ID`, `FULLNAME`,`SEX`,`DOB`,`CIVIL`, CONCAT(`NO`,`STREET`,`PRK`)AS ADDRESS, `PURPOSE`, `ORNo`,`DATEGIVEN`,BRGYCAPTAIN FROM `tblbrgyclearance` c, tblresidence r WHERE c.`RESID` = r.RESIDENCEID and FULLNAME LIKE '%" & txtsearch.Text & "%'")
        LoadBrgyClearance(DataGridView1, "brgy")
    End Sub

    Private Sub frmbrgyClearance_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        jokenfindthis("SELECT `ID`, `FULLNAME`,`SEX`,`DOB`,`CIVIL`, CONCAT(`NO`,`STREET`,`PRK`)AS ADDRESS, `PURPOSE`, `ORNo`,`DATEGIVEN`,BRGYCAPTAIN FROM `tblbrgyclearance` c, tblresidence r WHERE c.`RESID` = r.RESIDENCEID")
        LoadBrgyClearance(DataGridView1, "brgy")


    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        With frmnewBrgyClearance
            GLOBALid = DataGridView1.CurrentRow.Cells(0).Value

            jokenfindthis("SELECT `ID`, `FULLNAME`,`SEX`,`DOB`,`CIVIL`, CONCAT(`NO`,`STREET`,`PRK`)AS ADDRESS, `PURPOSE`, `ORNo`,`DATEGIVEN`,BRGYCAPTAIN,ISSUEDBY,`ISSUEDON`, `ISSUEDAT`, `RESCERT`, `RESSISSUEDON`, `RESSISSUEDAT` FROM `tblbrgyclearance` c, tblresidence r WHERE c.`RESID` = r.RESIDENCEID and ID=" & GLOBALid & "")
            loadsingleBrgy("brgy")

 

            .Lblsupliertitle.Text = "Edit Brgy. Clearance"
            .btnsave.Text = "Update"
            .btnsearch.Enabled = False

            .Show()

        End With
    End Sub
End Class