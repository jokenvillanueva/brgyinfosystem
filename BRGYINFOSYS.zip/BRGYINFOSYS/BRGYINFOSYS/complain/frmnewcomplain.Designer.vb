﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmnewcomplain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.lblresid = New System.Windows.Forms.Label
        Me.txtnature = New System.Windows.Forms.TextBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.TXTREMARKS = New System.Windows.Forms.ComboBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtencoder = New System.Windows.Forms.TextBox
        Me.brgycaptain = New System.Windows.Forms.Label
        Me.dtdate = New System.Windows.Forms.DateTimePicker
        Me.Label13 = New System.Windows.Forms.Label
        Me.txtdetailedrem = New System.Windows.Forms.TextBox
        Me.txtrespondents = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtdetails = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtcomplainant = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.txtcase = New System.Windows.Forms.TextBox
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Lblsupliertitle = New System.Windows.Forms.Label
        Me.btnsave = New System.Windows.Forms.Button
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.StatLbltime = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblresid
        '
        Me.lblresid.AutoSize = True
        Me.lblresid.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblresid.Location = New System.Drawing.Point(144, 12)
        Me.lblresid.Name = "lblresid"
        Me.lblresid.Size = New System.Drawing.Size(69, 16)
        Me.lblresid.TabIndex = 77
        Me.lblresid.Text = "Fullname :"
        Me.lblresid.Visible = False
        '
        'txtnature
        '
        Me.txtnature.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtnature.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtnature.BackColor = System.Drawing.SystemColors.HighlightText
        Me.txtnature.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtnature.Location = New System.Drawing.Point(146, 169)
        Me.txtnature.Name = "txtnature"
        Me.txtnature.Size = New System.Drawing.Size(197, 22)
        Me.txtnature.TabIndex = 76
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.StatLbltime)
        Me.GroupBox1.Controls.Add(Me.TXTREMARKS)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.lblresid)
        Me.GroupBox1.Controls.Add(Me.txtnature)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtencoder)
        Me.GroupBox1.Controls.Add(Me.brgycaptain)
        Me.GroupBox1.Controls.Add(Me.dtdate)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.txtdetailedrem)
        Me.GroupBox1.Controls.Add(Me.txtrespondents)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txtdetails)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.txtcomplainant)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.txtcase)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 63)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(424, 376)
        Me.GroupBox1.TabIndex = 41
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Details"
        '
        'TXTREMARKS
        '
        Me.TXTREMARKS.FormattingEnabled = True
        Me.TXTREMARKS.Items.AddRange(New Object() {"SETTLED", "UNSETTLED"})
        Me.TXTREMARKS.Location = New System.Drawing.Point(145, 198)
        Me.TXTREMARKS.Name = "TXTREMARKS"
        Me.TXTREMARKS.Size = New System.Drawing.Size(197, 21)
        Me.TXTREMARKS.TabIndex = 80
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(43, 147)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(97, 16)
        Me.Label4.TabIndex = 79
        Me.Label4.Text = "Time of Filling :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(38, 175)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(103, 16)
        Me.Label3.TabIndex = 75
        Me.Label3.Text = "Nature of Case :"
        '
        'txtencoder
        '
        Me.txtencoder.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtencoder.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtencoder.BackColor = System.Drawing.SystemColors.HighlightText
        Me.txtencoder.Enabled = False
        Me.txtencoder.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtencoder.Location = New System.Drawing.Point(146, 334)
        Me.txtencoder.Name = "txtencoder"
        Me.txtencoder.Size = New System.Drawing.Size(196, 22)
        Me.txtencoder.TabIndex = 60
        '
        'brgycaptain
        '
        Me.brgycaptain.AutoSize = True
        Me.brgycaptain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.brgycaptain.Location = New System.Drawing.Point(67, 340)
        Me.brgycaptain.Name = "brgycaptain"
        Me.brgycaptain.Size = New System.Drawing.Size(65, 16)
        Me.brgycaptain.TabIndex = 59
        Me.brgycaptain.Text = "Encoder :"
        '
        'dtdate
        '
        Me.dtdate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtdate.Location = New System.Drawing.Point(145, 117)
        Me.dtdate.Name = "dtdate"
        Me.dtdate.Size = New System.Drawing.Size(197, 20)
        Me.dtdate.TabIndex = 61
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(17, 276)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(123, 16)
        Me.Label13.TabIndex = 25
        Me.Label13.Text = "Detailed Remarks :"
        '
        'txtdetailedrem
        '
        Me.txtdetailedrem.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtdetailedrem.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtdetailedrem.BackColor = System.Drawing.SystemColors.HighlightText
        Me.txtdetailedrem.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdetailedrem.Location = New System.Drawing.Point(145, 270)
        Me.txtdetailedrem.Multiline = True
        Me.txtdetailedrem.Name = "txtdetailedrem"
        Me.txtdetailedrem.Size = New System.Drawing.Size(273, 58)
        Me.txtdetailedrem.TabIndex = 65
        '
        'txtrespondents
        '
        Me.txtrespondents.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtrespondents.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtrespondents.BackColor = System.Drawing.SystemColors.HighlightText
        Me.txtrespondents.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtrespondents.Location = New System.Drawing.Point(146, 89)
        Me.txtrespondents.Name = "txtrespondents"
        Me.txtrespondents.Size = New System.Drawing.Size(197, 22)
        Me.txtrespondents.TabIndex = 62
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(45, 95)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(95, 16)
        Me.Label1.TabIndex = 61
        Me.Label1.Text = "Respondents :"
        '
        'txtdetails
        '
        Me.txtdetails.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtdetails.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtdetails.BackColor = System.Drawing.SystemColors.HighlightText
        Me.txtdetails.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdetails.Location = New System.Drawing.Point(145, 229)
        Me.txtdetails.Multiline = True
        Me.txtdetails.Name = "txtdetails"
        Me.txtdetails.Size = New System.Drawing.Size(272, 35)
        Me.txtdetails.TabIndex = 64
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(83, 235)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(56, 16)
        Me.Label7.TabIndex = 65
        Me.Label7.Text = "Details :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(71, 203)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(69, 16)
        Me.Label5.TabIndex = 61
        Me.Label5.Text = "Remarks :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(46, 121)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(95, 16)
        Me.Label6.TabIndex = 63
        Me.Label6.Text = "Date of Filling :"
        '
        'txtcomplainant
        '
        Me.txtcomplainant.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtcomplainant.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtcomplainant.BackColor = System.Drawing.SystemColors.HighlightText
        Me.txtcomplainant.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcomplainant.Location = New System.Drawing.Point(146, 61)
        Me.txtcomplainant.Name = "txtcomplainant"
        Me.txtcomplainant.Size = New System.Drawing.Size(197, 22)
        Me.txtcomplainant.TabIndex = 48
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(71, 37)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(70, 16)
        Me.Label15.TabIndex = 28
        Me.Label15.Text = "Case No. :"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(51, 67)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(89, 16)
        Me.Label11.TabIndex = 21
        Me.Label11.Text = "Complainant :"
        '
        'txtcase
        '
        Me.txtcase.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtcase.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtcase.BackColor = System.Drawing.SystemColors.HighlightText
        Me.txtcase.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcase.Location = New System.Drawing.Point(146, 31)
        Me.txtcase.Name = "txtcase"
        Me.txtcase.Size = New System.Drawing.Size(197, 22)
        Me.txtcase.TabIndex = 1
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.Highlight
        Me.Panel2.Controls.Add(Me.Lblsupliertitle)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(452, 60)
        Me.Panel2.TabIndex = 42
        '
        'Lblsupliertitle
        '
        Me.Lblsupliertitle.AutoSize = True
        Me.Lblsupliertitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblsupliertitle.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Lblsupliertitle.Location = New System.Drawing.Point(17, 20)
        Me.Lblsupliertitle.Name = "Lblsupliertitle"
        Me.Lblsupliertitle.Size = New System.Drawing.Size(162, 25)
        Me.Lblsupliertitle.TabIndex = 0
        Me.Lblsupliertitle.Text = "New Complain"
        '
        'btnsave
        '
        Me.btnsave.Location = New System.Drawing.Point(159, 445)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(159, 39)
        Me.btnsave.TabIndex = 43
        Me.btnsave.Text = "Save"
        Me.btnsave.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        '
        'StatLbltime
        '
        Me.StatLbltime.AutoSize = True
        Me.StatLbltime.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatLbltime.Location = New System.Drawing.Point(146, 147)
        Me.StatLbltime.Name = "StatLbltime"
        Me.StatLbltime.Size = New System.Drawing.Size(49, 16)
        Me.StatLbltime.TabIndex = 81
        Me.StatLbltime.Text = "Label2"
        '
        'frmnewcomplain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(452, 495)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.btnsave)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "frmnewcomplain"
        Me.ShowIcon = False
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lblresid As System.Windows.Forms.Label
    Friend WithEvents txtnature As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtencoder As System.Windows.Forms.TextBox
    Friend WithEvents brgycaptain As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtdetailedrem As System.Windows.Forms.TextBox
    Friend WithEvents txtrespondents As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtdetails As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtcomplainant As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtcase As System.Windows.Forms.TextBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Lblsupliertitle As System.Windows.Forms.Label
    Friend WithEvents btnsave As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents dtdate As System.Windows.Forms.DateTimePicker
    Friend WithEvents TXTREMARKS As System.Windows.Forms.ComboBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents StatLbltime As System.Windows.Forms.Label
End Class
