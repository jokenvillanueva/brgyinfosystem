﻿Public Class frmcomplain

    Private Sub frmcomplain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        jokenfindthis("SELECT `ID`, `CASENO`, `ComplainantFullName`, `RespondentFullName`, `DateofFiling`,TIME_FORMAT(  `TimeofFiling` ,  '%H:%i:%s' ) as timefile, `NatureOfCase`, `Remarks`, `Details`, `Remarksdet`, `encoder` FROM `tblomplain` WHERE 1")
        LoadComplain(DataGridView1, "Complain")
    End Sub

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        frmnewcomplain.Timer1.Start()
        frmnewcomplain.Show()
        frmnewcomplain.txtencoder.Text = fullname
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        With frmnewcomplain
            GLOBALid = DataGridView1.CurrentRow.Cells(0).Value

            jokenfindthis("SELECT `ID`, `CASENO`, `ComplainantFullName`, `RespondentFullName`, `DateofFiling`,TIME_FORMAT(  `TimeofFiling` ,  '%H:%i:%s' ) as timefile, `NatureOfCase`, `Remarks`, `Details`, `Remarksdet`, `encoder` FROM `tblomplain` WHERE ID=" & GLOBALid & "")
            loadsingleComplain("Complain")

            .Lblsupliertitle.Text = "Edit Complain Information"
            .btnsave.Text = "Update"
            .Show()

        End With

    End Sub
End Class