﻿Public Class frmnewcomplain

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        If btnsave.Text = "Save" Then
            sql = "INSERT INTO `tblomplain` (`CASENO`, `ComplainantFullName`, `RespondentFullName`, " & _
            " `DateofFiling`, `TimeofFiling`, `NatureOfCase`, `Remarks`, `Details`, `Remarksdet`, `encoder`)" & _
            " VALUES (@CASENO, @ComplainantFullName, @RespondentFullName,@DateofFiling, @TimeofFiling, @NatureOfCase, @Remarks, @Details, @Remarksdet, @encoder);"

            issucess = SaveComplain("SaveOnly", sql)

            If issucess = True Then
                MsgBox("New Complain has been added!")
            Else
                MsgBox("No Complain has been added!")
            End If

            jokenfindthis("SELECT `ID`, `CASENO`, `ComplainantFullName`, `RespondentFullName`, `DateofFiling`,TIME_FORMAT(  `TimeofFiling` ,  '%H:%i:%s' ) as timefile, `NatureOfCase`, `Remarks`, `Details`, `Remarksdet`, `encoder` FROM `tblomplain` WHERE 1")
            LoadComplain(frmcomplain.DataGridView1, "Complain")
            Me.Close()
        Else
            sql = "UPDATE `tblomplain` SET  `ComplainantFullName` = @ComplainantFullName, `RespondentFullName` = @RespondentFullName, " & _
            "   `NatureOfCase` = @NatureOfCase, `Remarks` = @Remarks, `Details` = @Details, `Remarksdet` = @Remarksdet WHERE `tblomplain`.`ID` = @ID;"

            issucess = SaveComplain("UpdateOnly", sql)

            If issucess = True Then
                MsgBox("Complain has been updated!")
            Else
                MsgBox("No Complain has been updated!")
            End If

            jokenfindthis("SELECT `ID`, `CASENO`, `ComplainantFullName`, `RespondentFullName`, `DateofFiling`,TIME_FORMAT(  `TimeofFiling` ,  '%H:%i:%s' ) as timefile, `NatureOfCase`, `Remarks`, `Details`, `Remarksdet`, `encoder` FROM `tblomplain` WHERE 1")
            LoadComplain(frmcomplain.DataGridView1, "Complain")
            Me.Close()

        End If
    End Sub

   
    Private Sub frmnewcomplain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Timer1.Start()

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        StatLbltime.Text = Date.Now.ToString("H:mm:ss")
    End Sub
End Class