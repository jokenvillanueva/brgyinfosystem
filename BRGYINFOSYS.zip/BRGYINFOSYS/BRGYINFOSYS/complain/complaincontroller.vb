﻿Module complaincontroller

    Public Function SaveComplain(ByVal saving As String, ByVal sqlstring As String) As Boolean

        Try


            If saving = "SaveOnly" Then
                sql = sqlstring
            ElseIf saving = "UpdateOnly" Then
                sql = sqlstring

            End If
            con.Open()
            cmd.Connection = con
            cmd.CommandText = sql
            With frmnewcomplain
                If saving = "SaveOnly" Then
                    'NSERT INTO `tblomplain` (`CASENO`, `ComplainantFullName`, `RespondentFullName`, " & _
                    '" `DateofFiling`, `TimeofFiling`, `NatureOfCase`, `Remarks`, `Details`, `Remarksdet`, `encoder`)" & _
                    '" VALUES (@CASENO, @ComplainantFullName, @RespondentFullName,@DateofFiling, @TimeofFiling, @NatureOfCase, @Remarks, @Details, @Remarksdet, @encoder);"


                    cmd.Parameters.AddWithValue("@CASENO", .txtcase.Text)
                    cmd.Parameters.AddWithValue("@ComplainantFullName", .txtcomplainant.Text)
                    cmd.Parameters.AddWithValue("@RespondentFullName", .txtrespondents.Text)
                    cmd.Parameters.AddWithValue("@DateofFiling", Format(.dtdate.Value, "yyyy-MM-dd"))
                    cmd.Parameters.AddWithValue("@TimeofFiling", .StatLbltime.Text)
                    cmd.Parameters.AddWithValue("@NatureOfCase", .txtnature.Text)
                    cmd.Parameters.AddWithValue("@Remarks", .TXTREMARKS.Text)
                    cmd.Parameters.AddWithValue("@Details", .txtdetails.Text)
                    cmd.Parameters.AddWithValue("@Remarksdet", .txtdetailedrem.Text)
                    cmd.Parameters.AddWithValue("@encoder", .txtencoder.Text)


                ElseIf saving = "UpdateOnly" Then
                    '"UPDATE `tblomplain` SET  `ComplainantFullName` = @ComplainantFullName, `RespondentFullName` = @RespondentFullName, " & _
                    '"   `NatureOfCase` = @NatureOfCase, `Remarks` = @Remarks, `Details` = @Details, `Remarksdet` = @Remarksdet WHERE `tblomplain`.`ID` = @ID;"

                    cmd.Parameters.AddWithValue("@ComplainantFullName", .txtcomplainant.Text)
                    cmd.Parameters.AddWithValue("@RespondentFullName", .txtrespondents.Text)
                    cmd.Parameters.AddWithValue("@NatureOfCase", .txtnature.Text)
                    cmd.Parameters.AddWithValue("@Remarks", .TXTREMARKS.Text)
                    cmd.Parameters.AddWithValue("@Details", .txtdetails.Text)
                    cmd.Parameters.AddWithValue("@Remarksdet", .txtdetailedrem.Text)
                    cmd.Parameters.AddWithValue("@ID", GLOBALid)

                End If

            End With
            result = cmd.ExecuteNonQuery
            If result > 0 Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            cmd.Parameters.Clear()
            cmd.Dispose()
            con.Close()

        End Try
    End Function

    Public Sub LoadComplain(ByVal obj As Object, ByVal param As String)
        Try
            con.Open()
            dReader = cmd.ExecuteReader()
            '  obj.Rows.Clear()
            Select Case param
                Case "Complain"
                    obj.Rows.Clear()
                    Do While dReader.Read = True
                        obj.Rows.Add(dReader(0), dReader(1), dReader(2), dReader(3), dReader(4), dReader(5), dReader(6), dReader(7), dReader(8), dReader(9), dReader(10))

                    Loop
            End Select
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            da.Dispose()
            con.Close()
        End Try
    End Sub



    Public Sub loadsingleComplain(ByVal param As String)
        Try
            con.Open()
            dReader = cmd.ExecuteReader()
            '  obj.Rows.Clear()
            Select Case param
                Case "Complain"
                    Do While dReader.Read = True
                        With frmnewcomplain
                            '`ID`, `CASENO`, `ComplainantFullName`, `RespondentFullName`, `DateofFiling`, 
                            '`TimeofFiling`, `NatureOfCase`, `Remarks`, `Details`, `Remarksdet`, `encoder`
                            .Text = dReader("ID")
                            .txtcase.Text = dReader("CASENO")
                            .txtcomplainant.Text = dReader("ComplainantFullName")
                            .txtrespondents.Text = dReader("RespondentFullName")
                            .dtdate.Value = Format(dReader("DateofFiling"), "yyyy-MM-dd")
                            .StatLbltime.Text = dReader("timefile")
                            .txtnature.Text = dReader("NatureOfCase")
                            .TXTREMARKS.Text = dReader("Remarks")
                            .txtdetails.Text = dReader("Details")
                            .txtdetailedrem.Text = dReader("Remarksdet")
                            .txtencoder.Text = dReader("encoder")


                        End With

                    Loop
            End Select
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            da.Dispose()
            con.Close()
        End Try
    End Sub
End Module
