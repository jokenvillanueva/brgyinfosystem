﻿Public Class LoginForm1

    ' TODO: Insert code to perform custom authentication using the provided username and password 
    ' (See http://go.microsoft.com/fwlink/?LinkId=35339).  
    ' The custom principal can then be attached to the current thread's principal as follows: 
    '     My.User.CurrentPrincipal = CustomPrincipal
    ' where CustomPrincipal is the IPrincipal implementation used to perform authentication. 
    ' Subsequently, My.User will return identity information encapsulated in the CustomPrincipal object
    ' such as the username, display name, etc.

    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click
        sql = "SELECT count(*) as Numresult,`EMPID`, `EMPNAME`, `EMPADDRESS`, `EMPCONTACT`, `EMPPOSITION`, " & _
                " `USERNAME`, `PASSWRD`, `ACCSTATUS` FROM `tblemployee` WHERE `USERNAME` ='" & UsernameTextBox.Text & "' and `PASSWRD` = sha1('" & PasswordTextBox.Text & "')"
        jokenfindthis(sql)
        If NumRows() > 0 Then
            loadsingleUser("login")
            Main.TSUser.Text = fullname
            Main.TLlogin.Text = "Logout"

            Visible_Button(True)
        Else
            MsgBox("Username or Password not registered!")
        End If


        Me.Close()
    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        Me.Close()
    End Sub

End Class
